#!/usr/bin/perl
#
# $Header: rdbms/demo/rman_xttconvert/xttdriver.pl /main/14 2018/01/29 19:41:28 molagapp Exp $
#
# xttdriver.pl
#
# Copyright (c) 2013, 2018, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      xttdriver.pl - Cross Platform Transportable Tablespace DRIVER perl
#                     script
#
#    DESCRIPTION
#      The script that is run to perform the main steps of the XTTS with Cross
#      Platform Incremental Backups procedure.
#
#    VERSION
#      V4
#
#    NOTES
#      July 2019 [Version 4.3]
#        1. Fix for bugs 29862901, 29966954
#
#      April 2019 [Version 4.2]
#        1. Fix for bug 29337224
#
#      November 29, 2018 - Released V4
#
#      In version 4 important features are:
#        1.  Multi-tenant support
#		   2.  Simplified steps
#        
#      In version 3 important features are
#        1. Standby support
#        2. Allow new datafiles/tablespaces to be added during anypoint of 
#           script execution.
#        3. Move all temp files into appropriate directories, so that its 
#           easier to manage.
#        4. When rollforward fails, the script can now resume from where it failed
#           after the fix rather than start all over from first again
#
#      In version 2 12C options have been added which supports
#      "backup for transport" and "restore from platform"
#
#      In version 1.4 two new options -P and -G have been added.
#
#      In the current flow the datafiles are transported using a staging area
#      in the source and desination. This has been eliminated by using
#      dbms_file_transfer.
#
#      Parallelism is supported for rollforward if rollparallel is set
#
#    Bug Fixes
#    ==========
#      June 28 2018 [Version 3.2]
#      ----------------------------
#        1. Support tablespace string of more than 2999 characters 
#       
#      May 23 2017 [Version 3.0.1]
#      ----------------------------
#        1. Bug 22570430: UNABLE TO CONNECT TO PDB USING XTTDRIVER.PL 
#        2. Bug 19819438: XTTDRIVER.PL CDB SUPPORT 
#       
#      Dec 01 2016 [Version 3]
#      ----------------------------
#        1. Bug 22352281: Don't query the platform name for DB versions less
#           than 12c
#        2. Enh 25192728: Use "_" instead of "." in ASM names during 
#           restore/recover to workaround bug 25183374 
#       
#      Oct 03 2016 [Version 2.0.1]
#      ----------------------------
#        1. Bug 22638723 : when asm contains the same filename the duplicate is
#                          rejected
#        2. Bug 22598418 : RMAN-00556: could not open cmdfile when tabelspace 
#                          has many datafiles.
#
#      Apr 24 2015 [Version 2]
#      ----------------------------
#        1. Bug 20916691: --backup option broken
#        2. Bug 21028174: Add message when -L option is used
#
#      Nov 19 2014 [Version 2]
#      ------------------------------
#      Project 47110: New options have been added
#        1. --backup
#        2. --restore
#        3. --bkpincr
#        4. --bkpexport
#        5. --resincrdmp
#        6. Bug 20192155: Fix for ORA-15126
#        7. Added --version option to give version
#        8. Added multiple source and destination directory support in getfile.
#        9. Removed putfile code
#
#      Nov 14 2014 [Version 1.4.2]
#      ------------------------------
#        1. Enhancement: Added getparallel option to transfer datafiles in
#           parallel.
#
#      March 24 2014 [Version 1.4.1]
#      ------------------------------
#        1. 18456868 - Made sure sqlplus and rman is present in the PATH
#        2. 18456834 - Added new option -F/--propfile to pass the location
#              of properties file if required. This was requested by EM.
#        3. 18459238 - dfcopydir was not required when we run using -G
#           option. The checking has been enhanced.
#        4. Even when convert instance is used, the -G should be run only
#           from destination instance and not the conversion instance
#        5. Impdp added ';' at the end which resulted in error. Fixed this
#        6. Added more debugging messages
#        7. Do more error checking before proceeding to next steps
#        8. Bug 17819946 - When number of tablespaces is more, the length
#           of list exceeds 2499 and fails. This is also fixed
#        9. If debug option is set to more than 1 the temporary files are
#           preserved. Otherwise it is deleted.
#       10. Bug 18797439 - Add new option -I/--propdir. All required files
#           will be picked from the runtime location of xttdriver.pl
#       11. Clean up the code such that the temp files are more readable
#           and can be mapped to backups
#
#    MODIFIED   (MM/DD/YY)
#    asathyam    06/28/18 - Support > 2999 characters in tbs string 
#    molagapp    01/11/18 - bug 27355000
#    molagapp    05/14/17 - bug 22570430 - xttdriver support for CDB
#    asathyam    04/04/17 - Ver 3
#    bhaveshp    10/02/16 - Bug 22638723 - when asm contains the same filename 
#                           the duplicate is rejected.
#                           Bug 22598418 - RMAN-00556: could not open cmdfile 
#                           when tabelspace has many datafiles.
#    asathyam    12/24/14 - Ver2 more changes
#    asathyam    11/18/14 - Version 2
#    asathyam    11/11/14 - Get parallel implemenation for getfile
#    asathyam    05/19/14 - EM wanted only propfile to be picked from
#                           specified location.
#    asathyam    03/26/14 - Bug fixes. Details mentioned above
#    asathyam    01/30/14 - Implement doug's comments
#    asathyam    11/17/13 - Added support for same endian support
#    asathyam    10/20/13 - Bug 17673485 :- Added new option to support
#                           individual specified tablespaces to be roll
#                           forwarded in parallel
#    asathyam    10/02/13 - Bug 17673476 :- Fixed ASM related issues
#    asathyam    05/28/13 - New version 1.4
#    svrrao      03/15/13 - Enhance to v1.3. Introduce parallelism
#    fsanchez    03/15/13 - Creation

#
# Globals
#
use Getopt::Long qw(:config no_ignore_case);
use POSIX ":sys_wait_h";
use strict;
use Fcntl qw(:flock);
use vars qw/ %opt /;
our %transfer = ();
our $context = \%opt;
our @tablespaces = ();
our @properties = ();
our %props;
our $tmp;
our $xttpath;
our $rmantfrdf;
our $rmandstdf;
our $xttprep;
our $rmanpath;
our $connectstring;
our $sql_src_connstr;
our $rman_src_connstr;
our $rman_dest_connstr;
our $sqlSettings;
our $errfile;
our $getfile;
our $xtts_incr_backup = "xib";
our @rolltbsArray = ();
my %tbsHash;
my $fixCnvSql;
my $fixRollSql;
our @forkArray = ();
my $xttrollforwardp;
our $rollParallel = 0;
my $getParallel = 0;
my $metaTransfer = 0;
my $scpParms = 0;
our $xttprop;
our $cnvrSql       = "xttcnvrtbkupdest.sql";
our $stageondest;
our $backupondest;
our $platformid;
our $connectstringcnvinst;
our $myversion = "4.3";
our %dirHash;
our $dirmaxVal = 100;
our $rmanLog;
our $traceLog;
our $tstamp;
our $tmpMisc;
our @impXTTFiles = ("xttnewdatafiles.txt", "xttplan.txt", 
                    "tsbkupmap.txt", "xttplan.txt.new");
our @filesBkArray = ();
our $allowStby = 'N';
our $compFile = '';
our $dfLck    = '';
our $dfCopyFile;
our $failedDf;
our $tsbkupmap;
our $tsbkupmapWhole;
our $resFile;
our $xttplan;
our $xttplanNew;
our $xttnew;
our $tbsMap;
our $newfileAdded;
our $platId;

# To overcome 4999 character limit split the tbs string into multiple arrays
our $numTbArrays = 64;
our @tbsArrayRef;

# Following constants are for the options that are used in the perl script
use constant PREPARE      => 1;
use constant BCKPINCR     => 2;
use constant NEWPLAN      => 3;
use constant GETFILE      => 5;
use constant BACKUP       => 6;
use constant RESTORE      => 7;
use constant RECOVER      => 8;
use constant ROLLFORWARD  => 9;
use constant RESINCRDMP   => 10;
use constant FIXNEWDFGET  => 11;

# Used for generating xttplugin.txt
use constant LOCALFILE  => 1;
use constant LINK       => 2;

# Used for checking version
use constant VER11     => 1;
use constant VER12     => 2;

$| = 1;
my $rman = "$ENV{ORACLE_HOME}/bin/rman";
my $rman_ra_args1 = " target ";
my $rman_ra_args2 = " catalog ";

my $sqlplus = "$ENV{ORACLE_HOME}/bin/sqlplus -s";
my $sqlplus_ra_args;
my $sqlplus_sys_args;
my $convertWait = 0;
my $statsFile = '';

###############################################################################
# Function : parseArg
# Purpose  : Command line options processing
# Inputs   : None
# Returns  : None
###############################################################################
sub parseArg
{
   GetOptions ($context,
               'backup|b',
               'bkpincr|B',
               'convert|c',
               'debug|d:i',
               'bkpexport|E',
               'generate|e',
               'incremental|i',
               'orahome|o=s',
               'prepare|p',
               'rollforward|r',
               'determinescn|s',
               'xttdir|D=s',
               'propfile|F=s',
               'getfile|G',
               'propdir',
               'clearerrorfile|L',
               'orasid|O=s',
               'restore|R',
               'recover|X',
               'resincrdmp|M',
               'rolltbs|T=s',
               'setupgetfile|S',
               'ignoreerrors',
               'version|v',
               'fixnewdf|W',
               'testing',
               'includeexport|I',
               'includeimport',
               'help|h'
              ) or usage();

   if ($context->{"help"})
   {
      usage();
   }

   if ($context->{"version"})
   {
      LogMessage ("Version is $myversion");
      exit (1);
   }

   if (defined ($context->{"debug"}) && ($context->{"debug"} == 0))
   {
      $context->{"debug"} = 1;
   }
   if ($ENV{'XTTDEBUG'})
   {
      $context->{"debug"} = $ENV{'XTTDEBUG'};
   }

   if ($ENV{'XTTTESTING'})
   {
      $context->{"debug"} = 5;
      $context->{"testing"} = 1;
   }

   if ($context->{"testing"})
   {
      $context->{"debug"} = 5;
   }

   # User provided a directory, start from there to pick up files
   if ($context->{"propdir"})
   {
      use File::Basename;
      chdir (dirname($0));
   }

   if ($context->{"propfile"})
   {
      $xttprop = $context->{"propfile"};
   }
   else
   {
      $xttprop = "xtt.properties";
   }
}

###############################################################################
# Function : touchErrFile
# Purpose  : Create the error file if requested
###############################################################################
sub touchErrFile
{
   my $message = $_[0];

   open ERRFILE, ">>$errfile";
   print ERRFILE "$message\n";
   close ERRFILE;
}

###############################################################################
# Function : Unlink
# Purpose  : Delete the file if the debug level is less than 2
###############################################################################
sub Unlink
{
   my $delFile = $_[0];
   my $force   = $_[1];

   if ($force || ($context->{"debug"} < 2))
   {
      unlink ($delFile);
   }
}

###############################################################################
# Function : GetRMANTrace
# Purpose  : Get the trace file name. If debug is enabled use trace file
#            otherwise just log.
###############################################################################
sub GetRMANTrace
{
   my $fileAppend = $_[0];
   my $trace = "";
   my $traceFile;
   my $logFile = "";

   $logFile = "$tmpMisc/rman_log_".$fileAppend.".log";
   if ($context->{"debug"})
   {
      $traceFile = "$tmpMisc/rman_trc_".$fileAppend.".trc";
      $trace = " debug trace $traceFile ";
   }

   if ($rmanLog)
   {
      $trace = $trace." log $logFile ";
   }
   return ($trace, $traceFile, $logFile);
}

###############################################################################
# Function : deleteErrFile
# Purpose  : check if the error file exists and delete
###############################################################################
sub deleteErrFile
{
   LogMessage ("Deleting error file");
   if (-e $errfile)
   {
      Unlink ($errfile, 1);
   }
}

###############################################################################
# Function : checkErrFile
# Purpose  : check if the error file exists
###############################################################################
sub checkErrFile
{
   if (-e $errfile)
   {
      {
die "
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Error:
------
      Some failure occurred. Check $errfile for more details
      If you have fixed the issue, please delete $errfile and run it
      again OR run xttdriver.pl with -L option
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
";
      }
   }
}

###############################################################################
# Function : Mylog
# Purpose  : Write message to logfile as well as on screen
###############################################################################
sub Mylog
{
   my $message    = $_[0];

   open FILEX, ">>$traceLog";
   print FILEX $message."\n";
   close FILEX;
   
   print $message."\n";
}

###############################################################################
# Function : debugscreen
# Purpose  : print if debug value is >= passed debug level
###############################################################################
sub debugscreen
{
   my $message    = $_[0];
   my $debuglevel = $_[1];

   if ($context->{"debug"} >= $debuglevel)
   {
      Mylog($_[0]);
   }
}

###############################################################################
# Function : debug
# Purpose  : print with level being 1
###############################################################################
sub debug
{
   debugscreen ($_[0], 1);
}

###############################################################################
# Function : debug3
# Purpose  : print with level being 3
###############################################################################
sub debug3
{
   debugscreen ($_[0], 3);
}

###############################################################################
# Function : debug4
# Purpose  : print with level being 4
###############################################################################
sub debug4
{
   debugscreen ($_[0], 4);
}

###############################################################################
# Function : debug5
# Purpose  : print with level being 5
###############################################################################
sub debug5
{
   debugscreen ($_[0], 5);
}

###############################################################################
# Function : Die
# Purpose  : Print message and exit
###############################################################################
sub Die
{
    my $message = $_[0];

    touchErrFile($message);
die "
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Error:
------
$message
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
";
}

###############################################################################
# Function : Die
# Purpose  : Print message and exit
###############################################################################
sub Warn
{
    my $message = $_[0];

print "
####################################################################
Warning:
------
$message
####################################################################
";
}

###############################################################################
# Function : trim
# Purpose  : To remove whitespace from the start and end of the string
###############################################################################
sub trim
{
    my $string = $_[0];
    #chomp($string);
    chomp($string);
    $string =~ s/^\s+//;
    $string =~ s/\s+$//;
    $string =~ s/\n|\t//;
    return $string;
}

###############################################################################
# Function : checkError
# Purpose  : check if any error was there and bail out
###############################################################################
sub checkError
{
   my ($errorMessage, $output) = @_;
   
   #No need to check for error when user does not want to
   if (defined($context->{"ignoreerrors"}))
   {
      return;
   }
   
   chomp ($output);
   $output = trim ($output);

   if (($output =~ /ORA[-][0-9]/) || ($output =~ /SP2-.*/))
   {
      Mylog($output);
      #hack
      if ($output =~ /IS READONLY/)
      {
         Warn("$errorMessage");
      }
      else
      {
         Die("$errorMessage");
      }
   }

   debug $output;
}

###############################################################################
# Function : LogMessage
# Purpose  : Print the message that is passed to it
# Inputs   : Any text
# Outputs  : None
# NOTES    : None
###############################################################################
sub LogMessage
{
    my $message = $_[0];

Mylog("
--------------------------------------------------------------------
$message
--------------------------------------------------------------------
");
}

###############################################################################
# Function : LogMessageScreen
# Purpose  : Print the message on screen that is passed to it
# Inputs   : Any text
# Outputs  : None
# NOTES    : None
###############################################################################
sub LogMessageScreen
{
    my $message = $_[0];

print
(
"============================================================
$message
=============================================================
"
);
}

###############################################################################
# Function : parseProperties
# Purpose  : Parse the properties file xtt.properties
###############################################################################
sub parseProperties
{
   LogMessage ("Parsing properties");

   # Check if any failure occured and stop exection
   checkErrFile();

   @properties = qw(tablespaces stageondest storageondest dfcopydir
                    backupondest backupformat platformid oracle_home_cnvinst
                    oracle_sid_cnvinst asm_home asm_sid dstlink
                    srcdir dstdir srclink rollparallel getfileparallel
                    metatransfer dest_host desttmpdir dest_user
                    srcconnstr destconnstr dest_scratch_location dest_datafile_location
                    src_scratch_location);

   open my $in, "$xttprop" or Die "$xttprop not found: $!";

   while(<$in>)
   {
      next if /^#/;
      $props{$1}=$2 while m/(\S+)=(.+)/g;
   }
   close $in;

   if ($context -> {"debug"})
   {
      foreach my $pkey (keys %props)
      {
         Mylog("Key: $pkey");
         Mylog("Values: $props{$pkey}");
      }
   }
   @tablespaces = split(/,/, $props{'tablespaces'});

   # In this release we don't support RMAN logging, will need to fix it and
   # support in Ver 3.1
   if (defined($props{'rmanlog'}))
   {
      $rmanLog = 0;
   }
   else
   {
      $rmanLog = 0;
   }

   $rollParallel = $props{'rollparallel'};
   $platId = $props{'platformid'};

   LogMessage ("Done parsing properties");
}

###############################################################################
# Function : check
# Purpose  : check if the properties were defined
###############################################################################
sub check
{
  my $arg = $_[0];
  my $key = $_[1];

  debug "ARGUMENT $key";

  if (!defined ($arg))
  {
     Die ("Please define xtt.properties:$key");
  }
}

###############################################################################
# Function : checkNoPwdSSHEnabled
# Purpose  : For putfile option few properties will be not be required, the
#            same applies for the plan option
###############################################################################
sub checkNoPwdSSHEnabled
{
   my $outFile = "";

   if ($metaTransfer == 0)
   {
      return;
   }

   $outFile = "$tmpMisc/transferFile.log";

   unless (system ("ssh $scpParms \"echo host\" 2> $outFile") == 0)
   {
      my @failArray = ();
      open FAIL, "$outFile";
      @failArray = <FAIL>;
      close FAIL;
      Die ("Passwordless SSH not enabled to machine\n@failArray");
   }
}

###############################################################################
# Function : transferFiles
# Purpose  : For putfile option few properties will be not be required, the
#            same applies for the plan option
###############################################################################
sub transferFiles
{
   my @trnsfrFiles = @_;
   my $output = 0;
   my $files = "";
   my $scpParmsL = "";
   my $outFile = "$tmpMisc/transferFile.log";

   if ($metaTransfer == 0)
   {
      return;
   }
   foreach my $x (@trnsfrFiles)
   {
      chomp($x);
      $files = $files."$x ";
   }
   $scpParmsL =
         "-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ".
         "NumberOfPasswordPrompts=0 ";
   unless (system ("scp $scpParmsL $files ".$context -> {"remoteConnect"}.
                     ":".$context->{'desttmp'}." 2> $outFile") == 0)
   {
      Mylog("scp $scpParmsL $files ".$context -> {"remoteConnect"}.
                     ":".$context->{'desttmp'}." 2> $outFile");
      my @failArray = ();
      open FAIL, "$outFile";
      @failArray = <FAIL>;
      close FAIL;
      Die ("Unable to transfer files to destination machine\n@failArray");
   }
   Unlink ($outFile);
}

###############################################################################
# Function : getParallelProp
# Purpose  : Find how many files can be fetchde in parallel
###############################################################################
sub getParallelProp
{
   my $propValue = $_[0];

   # We need to find how how many cores are there in the machine and then use
   # that number to see if what the user has provided is less than that
   # For now we assume that max is 8
   # use Sys::Info;
   # use Sys::Info::Constants qw( :device_cpu );
   # my $info = Sys::Info->new;
   # my $cpu  = $info->device( CPU => %options );
   #
   # printf "CPU: %s\n", scalar($cpu->identify)  || 'N/A';
   # printf "CPU speed is %s MHz\n", $cpu->speed || 'N/A';
   # printf "There are %d CPUs\n"  , $cpu->count || 1;
   # printf "CPU load: %s\n"       , $cpu->load  || 0;
   if ($propValue > 8)
   {
      $propValue = 8;
      LogMessage ("Maximum $propValue files will be fetched in parallel");
   }

   return $propValue;
}

###############################################################################
# Function : checkProps
# Purpose  : For putfile option few properties will be not be required, the
#            same applies for the plan option
###############################################################################
sub checkProps
{
   LogMessage ("Checking properties");

   # Check if any failure occured and stop exection
   checkErrFile();

   # The following are required irrespective of what option is used
   check $props{'tablespaces'},  $properties[0];
   check $props{'platformid'},   $properties[6];

   # if CDB is used, connect string must include PDB TNS
   # srcconnstr and/or destconnstr must be specified.
   if (defined $props{'srcconnstr'})
   {
      $rman_src_connstr = "$props{'srcconnstr'}";
      $sql_src_connstr = "$props{'srcconnstr'}";

      if ($sql_src_connstr =~ /sys\/(.*)/i)
      {
         $sql_src_connstr = $sql_src_connstr." as sysdba "; 
      }
   }
   else
   {
      $rman_src_connstr = " / ";
      $sql_src_connstr = " / as sysdba ";
   }
   
   if (defined $props{'destconnstr'})
   {
      $rman_dest_connstr = "$props{'destconnstr'}";
   }
   else
   {
      $rman_dest_connstr = " / ";
   }

   if (!defined($props{'parallel'}) ||
       $props{'parallel'} <= 0)
   {
      $props{'parallel'} = 8;
   }

   if (defined($props{'metatransfer'}))
   {
      if (!defined($props{'dest_host'}))
      {
         Die ("Files transfered requested, but remote host not defined");
      }
      if (!defined($props{'desttmpdir'}))
      {
         Die ("Files transfered requested, but remote dir not defined");
      }
      if (defined($props{'dest_user'}))
      {
         $context -> {"remoteConnect"} =
            $props{'dest_user'}."@".$props{'dest_host'};
      }
      else
      {
         $context -> {"remoteConnect"} = $props{'dest_host'};
      }
      $context -> {"desttmp"} = $props{'desttmpdir'};
      $metaTransfer = 1;
      $scpParms =
         "-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ".
         "NumberOfPasswordPrompts=0 ".$props{'dest_host'};
   }

   if (!defined($props{'getfileparallel'}) ||
       $props{'getfileparallel'} <= 0)
   {
      $getParallel = 1;
   }
   else
   {
      $getParallel = getParallelProp($props{'getfileparallel'});
   }

   # Depending on option the checks are done
   if (defined($context->{"setupgetfile"}) ||
       defined($context->{"getfile"}))
   {
      check $props{'srcdir'},   $properties[12];
      check $props{'dstdir'},   $properties[13];
      check $props{'srclink'},  $properties[14];
   }

   if (defined($props{'dest_scratch_location'}))
   {
      if (!defined($props{'stageondest'}))
      {
         $props{'stageondest'} = $props{'dest_scratch_location'};
      }
      if (!defined($props{'backupondest'}))
      {
         $props{'backupondest'} = $props{'dest_scratch_location'};
      }
   }

   if (defined($props{'dest_datafile_location'}))
   {
      if (!defined($props{'storageondest'}))
      {
         $props{'storageondest'} = $props{'dest_datafile_location'};
      }
   }

   if (defined($props{'src_scratch_location'}))
   {
      if (!defined($props{'backupformat'}))
      {
         $props{'backupformat'} = $props{'src_scratch_location'};
      }
      if (!defined($props{'dfcopydir'}))
      {
         $props{'dfcopydir'} = $props{'src_scratch_location'};
      }
   }

   check $props{'backupformat'}, $properties[5];
   
   if (defined($context->{"prepare"}))
   {
      check $props{'dfcopydir'}, $properties[3];
   }

   if (defined($context->{"rollforward"}))
   {
      check $props{'backupondest'}, $properties[4];
   }

   if (defined($context->{"srcdir"}) &&
       defined($context->{"dstdir"}))
   {
      my @srcDir = split(/,/, $props{'srcdir'});
      my @dstDir = split(/,/, $props{'dstdir'});
      my $dstCount = scalar (@dstDir);
      my $srcCount = scalar (@srcDir);
      if (($dstCount > 1) && ($srcCount != $dstCount))
      {
         Die ("checkProps: Number of source objects does not match ".
              "destination objects");
      }
      if ($dstCount >= $dirmaxVal)
      {
         Die ("checkProps: Number of dir objects cannot exceed $dirmaxVal");
      }
   }

   if (defined($props{'allowstandby'}))
   {
      $allowStby = 'Y';
   }

   $platformid   = $props{'platformid'};
   $stageondest  = $props{'stageondest'};
   $stageondest  = $props{'stageondest'};
   $backupondest = $props{'backupondest'};

   LogMessage ("Done checking properties");
}

###############################################################################
# Function : warnMesg
# Purpose  : Print message and exit
###############################################################################
sub warnMesg
{
    my $message = $_[0];

Mylog("
####################################################################
Warning:
--------
$message
####################################################################
");
}

sub RunSQLCmd
{
   my $sqlplus_args = $_[0];
   my $sqlplus_cmd = $_[1];
   my $exitScript = $_[2];
   my $exitVal = 0;
   my @resArray = ();
   my $failed = 1;

   if (defined($exitScript))
   {
      $exitVal = $$exitScript;
   }

   open( my $run, "$sqlplus $sqlplus_args $sqlplus_cmd|");
   while (<$run>)
   {
      my $return = $_;
      push(@resArray,$return);
      chomp($return);
      if (($return =~ /ORA[-][0-9]/) || ($return =~ /SP2-.*/))
      {
         if ($exitVal)
         {
            Die ("Error $sqlplus_cmd $return");
         }
         else
         {
            LogMessage("Error in $sqlplus_cmd $return");
            $$exitScript = 1;
            $failed = 1;
            last;
         }
      }
      $failed = 0;
      debug3($return);
   }
   close $run;
   if (defined($exitScript))
   {
      $$exitScript = $failed;
   }
   debug4("$sqlplus_cmd returned");
   debug4Array(\@resArray);
   return @resArray;
}

###############################################################################
# Function : checkDbLink
# Purpose  : To check if the given DB link works
###############################################################################
sub checkDbLink
{
   my $sqlOutput ;
   my $dblink = $_[0];
   my $sqlQuery =
      "select 'Count=' || count(*) from dual@"."$dblink;";

   $sqlOutput = `sqlplus -L -s $connectstring <<EOF
                         $sqlSettings
                         $sqlQuery
                         quit;
EOF
`;
   chomp ($sqlOutput);
   $sqlOutput = trim ($sqlOutput);

   if ($sqlOutput =~ m/^Count=(.*)/)
   {
      if ($1 <= 0)
      {
         Die ("Database link $props{'dstlink'} is not working");
      }
   }
   else
   {
      Die ($sqlOutput);
   }
}

###############################################################################
# Function : checkDBState
# Purpose  : To check state of database
###############################################################################
sub checkDBState
{
   my $sqlOutput ;
   my $dblink = $_[0];
   my $sqlQuery =
      'select \'STATUS=\' || status FROM v\$instance;';

   $sqlOutput = `sqlplus -L -s $connectstring <<EOF
                         $sqlSettings
                         $sqlQuery
                         quit;
EOF
`;
   chomp ($sqlOutput);
   $sqlOutput = trim ($sqlOutput);

   if ($sqlOutput =~ m/^STATUS=(.*)/)
   {
      my $startStatus = trim ($1);
      if ($startStatus ne "STARTED")
      {
         Die ("Open database in nomount mode and try rollforward again");
      }
   }
   else
   {
      Die ($sqlOutput);
   }
}

###############################################################################
# Function : checkCompat
# Purpose  : To check state of database
###############################################################################
sub checkCompat
{
   my $sqlOutput ;
   my $sqlQuery =
      'select to_number(replace(RPAD(value, 10, \'.0\'), \'.\')) from '.
      'v\$parameter WHERE name = \'compatible\';';

   $sqlOutput = `sqlplus -s -L $connectstring <<EOF
                         $sqlSettings
                         $sqlQuery
                         quit;
EOF
`;

   chomp ($sqlOutput);
   $sqlOutput = trim ($sqlOutput);

   debug "$sqlOutput\n";

   if ($sqlOutput =~ m/.*ORA-.*/)
   {
      Die ("Unable to check database compatibility");
   }

   if ($sqlOutput >= 121000)
   {
      return VER12;
   }
   else
   {
      return VER11;
   }
}

###############################################################################
# Function : checkStandby
# Purpose  : To check if we are running against standby
###############################################################################
sub checkStandby
{
   my $sqlOutput ;
   my $sqlQuery =
      'select database_role from v\$database;';

   $sqlOutput = `sqlplus -s -L $connectstring <<EOF
                         $sqlSettings
                         $sqlQuery
                         quit;
EOF
`;

   chomp ($sqlOutput);
   $sqlOutput = trim ($sqlOutput);

   debug "$sqlOutput\n";

   if ($sqlOutput =~ m/.*ORA-.*/)
   {
      Die ("Unable to check if we are running against standby");
   }

   if (($sqlOutput eq 'PRIMARY') or
       ($allowStby and
        $sqlOutput eq 'PHYSICAL STANDBY'))
   {
      debug3 ("Running on $sqlOutput");
   }
   else
   {
      Die("Unable to run script on $sqlOutput");
   }
}

###############################################################################
# Function : getPlatName
# Purpose  : To get name of source platform
###############################################################################
sub getPlatName
{
   my $sqlOutput ;
   my $sqlQuery =
      'select platform_name from v\$transportable_platform '.
      'where platform_id = '.$platId.';';

   $sqlOutput = `sqlplus -s -L $connectstring <<EOF
                         $sqlSettings
                         $sqlQuery
                         quit;
EOF
`;

   chomp ($sqlOutput);
   $sqlOutput = trim ($sqlOutput);

   if ($sqlOutput =~ m/.*ORA-.*/)
   {
      LogMessage($sqlOutput);
      Die ("Unable to fetch platform name");
   }

   return $sqlOutput;
}

###############################################################################
# Function : getCurrPlatName
# Purpose  : To get platform name of current db
###############################################################################
sub getCurrPlatName
{
   my $sqlOutput ;
   my $sqlQuery =
      'select platform_name from v\$database;';

   $sqlOutput = `sqlplus -s -L $connectstring <<EOF
                         $sqlSettings
                         $sqlQuery
                         quit;
EOF
`;

   chomp ($sqlOutput);
   $sqlOutput = trim ($sqlOutput);

   if ($sqlOutput =~ m/.*ORA-.*/)
   {
      LogMessage($sqlOutput);
      Die ("Unable to fetch platform name");
   }

   return $sqlOutput;
}

###############################################################################
# Function : fetchDirEntry
# Purpose  : In order to transfer the files we need to define directory
#            objects, this function will check if they are defined.
###############################################################################
sub fetchDirEntry
{
   my $dirtoCheck = $_[0];
   my $remoteLink = $_[1];
   my @sqlOutput ;
   my $sqlQuery ;

   debug3 "fetchDirEntry: parms $remoteLink, $dirtoCheck\n";

   if ($remoteLink eq "")
   {
      debug "fetchDirEntry: remotelink not present\n";
      $sqlQuery =
                  "SELECT 'DIRECTORY_NAME=' || DIRECTORY_NAME,
                          'DIRECTORY_PATH=' || DIRECTORY_PATH FROM ".
                  "ALL_DIRECTORIES WHERE DIRECTORY_NAME in ($dirtoCheck);";
   }
   else
   {
      $sqlQuery =
                  "SELECT 'DIRECTORY_NAME=' || DIRECTORY_NAME,
                          'DIRECTORY_PATH=' || DIRECTORY_PATH FROM ".
                  "ALL_DIRECTORIES\@".
                  "$remoteLink WHERE DIRECTORY_NAME in ($dirtoCheck);";
   }

   @sqlOutput = `sqlplus -L -s $connectstring <<EOF
                         $sqlSettings
                         $sqlQuery
                         quit;
EOF
`;

   chomp (@sqlOutput);

   return @sqlOutput;
}

###############################################################################
# Function : fetchCheckDirObjectsDST
# Purpose  : In order to transfer the files we need to define directory
#            objects, this function will check if they are defined.
###############################################################################
sub fetchCheckDirObjectsDST
{
   my $dirtoCheck = $_[0];
   my $remoteLink = $_[1];
   my $dirObjects = $_[2];
   my $dirtoCheckLink;
   my $dirObjPath;
   my @sqlOutput ;
   my $sqlQuery ;
   my $found ;
   my %dstHash = ();

   debug "fetchCheckDirObjectsDST: Check dir path $remoteLink\n";

   my @srcDir = split(/,/, $props{'srcdir'});
   my @dstDir = split(/,/, $props{'dstdir'});
   my $tempDir = '';
   my $idx = 0;
   my $dstCount = scalar (@dstDir);
   my $srcCount = scalar (@srcDir);

   if (($dstCount > 1) && ($srcCount != $dstCount))
   {
      Die ("fetchCheckDirObjectsDST: Number of source objects does not match ".
           "destination objects");
  }

   foreach my $var (@dstDir)
   {
      $var = trim($var);
      $tempDir = $tempDir."\'$var\',";
      $dstHash{"$var"} = trim($dstDir[$idx]);
      debug3 "fetchCheckDirObjectsDST: DestDir: ".$dstHash{"$var"}."\n";
      if ($dstCount > 1)
      {
         $idx = $idx + 1;
      }
   }

   if ($tempDir =~ m/(.*)\,/)
   {
      $tempDir = $1;
   }

   @sqlOutput = fetchDirEntry ($tempDir, $remoteLink);

   foreach my $x (@sqlOutput)
   {
      $x = trim ($x);
      if ($x =~ m/^DIRECTORY_NAME=(.*)DIRECTORY_PATH=(.*)/)
      {
         my $nameTemp = $1;
         $dirObjPath = $2;
         $nameTemp = trim($nameTemp);

         if ($dirObjPath =~ m/(.*)\/$/) # Removes trailing spaces
         {
            $dirObjPath = $1;
         }

         $dirObjects->{$nameTemp} = $dirObjPath;
      }
   }

   if ((keys%$dirObjects) == 0)
   {
      Mylog("fetchCheckDirObjectsDST: Directory ".
             "object \"$dirtoCheck\" does not exist");
      Die (@sqlOutput);
   }

   return $dirObjPath;
}

###############################################################################
# Function : fetchCheckDirObjectsSRC
# Purpose  : In order to transfer the files we need to define directory
#            objects, this function will check if they are defined.
###############################################################################
sub fetchCheckDirObjectsSRC
{
   my $dirtoCheck = $_[0];
   my $remoteLink = $_[1];
   my $dirObjects = $_[2];
   my $dirObjPath;
   my @sqlOutput ;
   my $sqlQuery ;
   my $found ;
   my %srcHash = ();

   debug "fetchCheckDirObjectsSRC: Check dir path $remoteLink\n";

   my @srcDir = split(/,/, $props{'srcdir'});
   my @dstDir = split(/,/, $props{'dstdir'});
   my $tempDir = '';
   my $idx = 0;
   my $dstCount = scalar (@dstDir);
   my $srcCount = scalar (@srcDir);

   if (($dstCount > 1) && ($srcCount != $dstCount))
   {
      Die ("fetchCheckDirObjectsSRC: Number of source objects does not match ".
           "destination objects");
  }

   foreach my $var (@srcDir)
   {
      $var = trim($var);
      $tempDir = $tempDir."\'$var\',";
      $srcHash{"$var"} = trim($dstDir[$idx]);
      debug3 "fetchCheckDirObjectsSRC: SRCDIR: ".$srcHash{"$var"}."\n";
      if ($dstCount > 1)
      {
         $idx = $idx + 1;
      }
   }

   if ($tempDir =~ m/(.*)\,/)
   {
      $tempDir = $1;
   }

   @sqlOutput = fetchDirEntry ($tempDir, $remoteLink);

   foreach my $x (@sqlOutput)
   {
      $x = trim ($x);
      debug5 "fetchCheckDirObjectsSRC: $x";
      if ($x =~ m/^DIRECTORY_NAME=(.*)DIRECTORY_PATH=(.*)/)
      {
         my $nameTemp = $1;
         $dirObjPath = $2;
         $nameTemp = trim($nameTemp);

         if ($dirObjPath =~ m/(.*)\/$/)
         {
            $dirObjPath = $1;
         }

         # Create a hash with SRC directory and the DST directory object names.
         $dirObjects->{$dirObjPath}->{"SRC"} = $nameTemp;
         $dirObjects->{$dirObjPath}->{"DST"} = $srcHash{"$nameTemp"};
      }
   }

   if ((keys%$dirObjects) == 0)
   {
      Mylog("fetchCheckDirObjectsSRC: Directory ".
             "object \"$dirtoCheck\" does not exist");
      Die (@sqlOutput);
   }

   return;
}

###############################################################################
# Function : fixXTTNewDatafiles
# Purpose  : Fix the destination file by replacing the tag DESTDIR with the
#            actual location
###############################################################################
sub fixXTTNewDatafiles
{
   my $dirObjects = $_[0];
   my $replaceFile = 0;
   my @destArray = ();

   open(RMANDSTDF, "$rmandstdf") ||
      Die "Can't find $rmandstdf";
   @destArray = <RMANDSTDF>;
   close RMANDSTDF;

   foreach my $line (@destArray)
   {
       if ($line =~ /.*DESTDIR:.*/)
       {
          $replaceFile = 1;
          last;
       }
   }

   if ($replaceFile)
   {
      my $rmandstdfT = "$tmpMisc/xttnewdatafiles.txt";
      open(RMANDSTDF1, ">$rmandstdfT") ||
         Die "Cant find $rmandstdfT";
      foreach my $line (@destArray)
      {
         if ($line =~ m/(.*),DESTDIR:(.*)\,(.*)/)
         {
            my $dest = $dirObjects->{$2}->{"DST"};
            print RMANDSTDF1 "$1,$dest".":$3\n";
         }
         else
         {
            print RMANDSTDF1 "$line";
         }
      }
      close RMANDSTDF1;
      checkMove("$rmandstdf", "$rmandstdf"."_temp");
      checkCopy($rmandstdfT, $rmandstdf);
   }
}

###############################################################################
# Function : CheckEleExists
# Purpose  : Check if duplicate element exists in array
###############################################################################
sub CheckEleExists
{
    my @array = @{$_[0]};
    my $ele = $_[1];
    if (grep(/^$ele$/i, @array))
    {
        return 1 ;
    }
    else
    {
        return 0;
    }
}

###############################################################################
# Function : fixXTTDupDatafiles
# Purpose  : Fix the destination file by replacing the tag DESTDIR with the
#            actual location
###############################################################################
sub fixXTTDupDatafiles
{
   my $dirObjects = $_[0];
   my @destArray = ();
   my @dupAsmArray = ();
   my $replaceFile = 0;
   my $fixFile  = "$tmp/fixedfile.txt.temp";
   my $fixFileF = "$tmp/fixedfile.txt";
   my $rmanStdDfT = "$rmandstdf".".temp";

   debug "fixXTTDupDatafiles: Entered";

   open(RMANDSTDF, "$rmandstdf") ||
      Die "Cant find $rmandstdf";
   @destArray = <RMANDSTDF>;
   close RMANDSTDF;

   open(RMANDSTDF1, ">$rmanStdDfT") ||
        Die "Cant find $rmanStdDfT";

   open(TMPFIXFILE, ">$fixFile") ||
        Die "Cant find $fixFile";
   foreach my $line (@destArray)
   {
      if ($line =~ /(.*),\+(.*)\/(.*)/)
      {
         my $dfno = $1;
         if (CheckEleExists (\@dupAsmArray,$3))
         {
            my $fno = $1;
            my $asm = $2;
            my $destFile = $3;
            my $origDestFile = $3;

            if ($destFile =~ m/(.*)\.(.*)/)
            {
               $destFile = $1."_".$dfno."_".$tstamp.".$2";
            }
            $replaceFile = 1;            
            print RMANDSTDF1 "$fno,+$asm"."/$destFile\n";
            print TMPFIXFILE "$origDestFile".":::"."$destFile\n";
         }
         else
         {
            print RMANDSTDF1 "$line";
            push (@dupAsmArray, $3);
         }
      }
      else
      {
         print RMANDSTDF1 "$line";
      }
   }
   close RMANDSTDF1;
   close TMPFIXFILE;

   if ($replaceFile)
   {
      Unlink ("$rmandstdf", 1);
      checkCopy($rmanStdDfT, $rmandstdf);
      checkMove($fixFile, $fixFileF);
   }
   else
   {
      checkMove($fixFile);
      checkMove($rmanStdDfT);
   }
   
   return @dupAsmArray;
}

###############################################################################
# Function : verifySrcdirDatafiles
# Purpose  : Verify if the datafiles are present in the same directory
#            as defined in the source directory object
###############################################################################
sub verifySrcdirDatafiles
{
   my $dfPath = "$tmpMisc/xttprepare.cmd";
   my @dfList = ();
   my @unidfList = ();
   my %seen;
   my $name;

   debug ("verifySrcdirDatafiles: Entered");

   open DFLIST, $dfPath ;
   @dfList = <DFLIST>;
   close DFLIST;

   foreach my $df (@dfList)
   {
      chomp ($df);
      debug3 "verifySrcdirDatafiles: $df";
      if ($df =~ /^#DNAME:(.*)/)
      {
         $name = $1;
         if (! (grep { $_ eq $name } @unidfList))
         {
            push (@unidfList, $1);
         }
      }
   }

   foreach my $key (keys %dirHash)
   {
      debug4 "verifySrcdirDatafiles: Hash key".$key."\n";
      debug4 "verifySrcdirDatafiles: Hash value".$dirHash{"$key"}."\n";
   }

   foreach my $df (@unidfList)
   {
      debug3 "verifySrcdirDatafiles: $df\n";
      if (!defined($dirHash{$df}))
      {
         Die ("Datafile path $df and source directory object ".
              "path ".$dirHash{$df}." doest not match");
      }
   }
}

##
## This routine is called from
## Prepare Src
## Backup Incr (backincr)
## New Plan (newplan)
## Getfile
## Helper routine to batch the tablespaces sent into control file
## queries, this way too many controlfile reads is avoided.
## It takes one parameter, to tell who called it
## 1 => Prepare, 2 => backincr, 3 => newplan, 5 => getfile
## 11 => FIXNEWDFGET
##
sub generate_batch_tsoutput()
{
   my $option        = $_[0];
   my $stageondest   = $props{'stageondest'};
   my $platform      = "'$props{'platform'}'";
   my $storageondest = $props{'storageondest'};
   my $dfcopydir     = $props{'dfcopydir'};
   my $backupformat  = $props{'backupformat'};
   my $script_type   = "PREPARE";
   my $output;
   my $incrbkups = "$tmpMisc/incrbackups.txt";
   @filesBkArray = ();

   my $number_of_tablespaces_per_batch =
      int(($#tablespaces + 1)/$props{'parallel'});

   # Check if any failure occured and stop exection
   checkErrFile();

   $number_of_tablespaces_per_batch = ($number_of_tablespaces_per_batch == 0)
                                      ? 1
                                      : $number_of_tablespaces_per_batch;

   my $total_sets = $number_of_tablespaces_per_batch * $props{'parallel'};

   debug3 $connectstring;
   debug3 "size of tablespace " . scalar(@tablespaces);
   debug3 "No. of tablespaces per batch " . $number_of_tablespaces_per_batch;

   my $countno = 0;
   my $tablespace_str  = "";
   my $old_tablespace_str  = "";

   if ($option == BACKUP)
   {
      checkMove ($tsbkupmap);
      checkMove ($incrbkups);
   }

   ## Generate the rmanconvert.cmd and xttplan.txt from the output
   ## for Prepare
   if (($option == PREPARE) || ($option == BACKUP) || 
       ($option == GETFILE) || ($option == FIXNEWDFGET))
   {
      if ($option == FIXNEWDFGET)
      {
         my $xttpathx = $xttpath."_tmp";
         open(XTTPLAN, ">$xttpathx") ||
            die 'Cant find xttplan.txt, TMPDIR undefined';
      }
      else
      {
         open(XTTPLAN, ">$xttpath") ||
            die 'Cant find xttplan.txt, TMPDIR undefined';
      }
      
      if ($option == PREPARE)
      {
         open(RMANCONVERT, ">$rmanpath") ||
             die 'Cant find rmanconvert.cmd, TMPDIR undefined';
      }
      # Generate new datafiles for 12c backup
      elsif ($option == BACKUP)
      {
         $script_type = "BACKUP";

         open(RMANDSTDF, ">$rmandstdf") ||
             die 'Cant find $rmandstdf, TMPDIR undefined';
      }
      elsif ($option == GETFILE)
      {
         $script_type = "TRANSFER";

         open(RMANDSTDF, ">$rmandstdf") ||
             die 'Cant find $rmandstdf, TMPDIR undefined';
      }
      elsif ($option == FIXNEWDFGET)
      {
         $script_type = "TRANSFER";

         my $rmandstdfx = $rmandstdf.".added";
         $rmandstdf = $rmandstdfx;
         open(RMANDSTDF, ">$rmandstdfx") ||
             die 'Cant find $rmandstdfx, TMPDIR undefined';
      }
   }
   elsif ($option == BCKPINCR)
   {
     open XTTNEWPLAN, ">$tmp/xttplan.txt.new" or die $!;

     $script_type = 'DETNEW';
   }
   elsif ($option == NEWPLAN)
   {
     $script_type = 'PREPNEXT';
   }

   ## Based on parallelism, do so many tablespaces at a time.
   my $ind = 0;
   while ($ind < $total_sets ||
          $ind < scalar(@tablespaces))
   {
      ## Remove leading and trailing spaces.
      $tablespaces[$ind] =~ s/^\s+//;
      $tablespaces[$ind] =~ s/\s+$//;

      ## grab the rest
      while ($ind < scalar(@tablespaces) &&
             $ind >= $total_sets)
      {
         $tablespace_str .= "'" . $tablespaces[$ind] . "'";
         if ($ind !=  $#tablespaces)
         {
            $tablespace_str .= ",";
         }
         $ind++;
      }

      if ($ind < $total_sets)
      {
         $tablespace_str .= "'" . $tablespaces[$ind] . "'";

         if (($ind % $number_of_tablespaces_per_batch) !=
             ($number_of_tablespaces_per_batch-1))
         {
            $tablespace_str .= ",";
         }

         $countno++;
         $ind++;
      }

      if (($countno == $number_of_tablespaces_per_batch ||
           $ind == scalar(@tablespaces)) &&
          $tablespace_str ne "''")
      {
        debug "TABLESPACE STRING :" . $tablespace_str;

        $countno = 0;

        ## Subst. for tablespace names
        open my $in, "xttprep.tmpl" or die $!;

        if (($option == PREPARE) || ($option == BACKUP) ||
            ($option == GETFILE) || ($option == FIXNEWDFGET))
        {
           Mylog("Prepare source for Tablespaces:
                  $tablespace_str  $stageondest");
           ## Open the pareparesrc.sql file and substitute all the parameters
           my $prepSrcSql = "$tmpMisc/xttpreparesrc.sql";
           open my $prepout, ">$prepSrcSql" or die $!;

           while(<$in>)
           {
              s/%%stageondest%%/$stageondest/;
              s/%%storageondest%%/$storageondest/;
              s/%%dfcopydir%%/$dfcopydir/;
              s/%%tmp%%/$tmpMisc/;
              s/%%parallel%%/$props{'parallel'}/;
              s/%%type%%/$script_type/;
              s/%%backupformat%%/$backupformat/;
              if ($option == FIXNEWDFGET)
              {
                 my $lallowStby = 'Y'; 
                 s/%%allowstandby%%/$lallowStby/;
              }
              else
              {
                 s/%%allowstandby%%/$allowStby/;
              }
              if ($_ =~ /%%TABLESPACES%%/)
              {
                 my @tbs = split(/,/, $tablespace_str);
                 foreach (@tbs)
                 {
                    print $prepout "$_,\n";
                 }
                 print $prepout "NULL\n";
              }
              else
              {
                 print $prepout "$_";
              }
           }

           close $in;
           close $prepout;

           ## timestamp here -- start
           Mylog("xttpreparesrc.sql for $tablespace_str started at ".
                  (localtime));

           ## Reset tablespace string
           $old_tablespace_str = $tablespace_str;
           $tablespace_str  = "";

           ## Substitution ends here and xttpreparesrc.sql generated
           my $output = `sqlplus -L -s $sql_src_connstr \@$prepSrcSql`;
           debug3($output);
           ## timestamp here -- end
           Mylog("xttpreparesrc.sql for $tablespace_str ended at ".
                  (localtime));
           checkError ("Error in executing $prepSrcSql", $output);

           my @line = split /\n/, $output;

            if (($option == BACKUP) || ($option == GETFILE) ||
                ($option == FIXNEWDFGET))
            {
               foreach my $line (@line)
               {
                  if ($line =~ /^#PLAN:/)
                  {
                     $line =~ s/^#PLAN://;
                     print XTTPLAN "$line\n";
                     if ($line =~ /(\S+)::::(\S+)/)
                     {
                        print RMANDSTDF "::$1\n";
                     }
                     if ($line !~ m/.*::::.*/)
                     {
                        push(@filesBkArray, $line);
                     }
                  }
                  elsif ($line =~ /^#TRANSFER:/)
                  {
                     $line =~ s/^#TRANSFER://;
                     if ($line =~ /.*source_file_name=(.*?),(.*?),(.*)/)
                     {
                        my $tsname = $1;
                        my $fullPath = trim($2);
                        my $fname = trim($3);

                        # Remove the trailing "/"
                        if ($fullPath =~ m/(.*)\/$/)
                        {
                           $fullPath = $1;
                        }

                        my $fullPath = $fullPath."/".$fname;
                        push(@{$transfer{$tsname}}, $fullPath);
                     }
                  }
                  elsif ($line =~ /^#NEWDESTDF:/)
                  {
                     $line =~ s/^#NEWDESTDF://;
                     print RMANDSTDF "$line\n";
                  }
               }
               # Verify that the files are in proper directory.
               &verifySrcdirDatafiles();
            }
            if (($option == BACKUP) || ($option == PREPARE))
            {
               foreach my $line (@line)
               {
                  if ($line =~ /^#PLAN:/)
                  {
                     $line =~ s/^#PLAN://;
                     print XTTPLAN "$line\n";
                     chomp($line);
                     if ($line !~ m/.*::::.*/)
                     {
                        push(@filesBkArray, $line);
                     }
                  }
                  elsif ($line =~ /^#CONVERT:/)
                  {
                     $line =~ s/^#CONVERT://;
                     print RMANCONVERT "$line \n";
                  }
               }
               ## Invoke the backup as copy routine once generated as the last
               ## step
               my $rmancopycmd = "$tmpMisc/xttprepare.cmd";

               $output = RunRmanCmd($rman_src_connstr, $rmancopycmd, "prepare");
               #checkMove($rmancopycmd);
               checkCopy($rmanpath);

               if ($option == BACKUP)
               {
                  # We need to generate tsbkpupmap.txt for
                  &gentablespace_backupmap( $output ) ;
               }
            }
        }
        elsif ($option == BCKPINCR)
        {
           ## Subst. for tablespace names

           Mylog("Prepare newscn for Tablespaces: $tablespace_str");

           ## Open the pareparesrc.sql file and substitute all the parameters
           my $prepNextFromScnSql = "$tmpMisc/xttpreparenextiter.sql";
           open my $prepout, ">$prepNextFromScnSql" or die $!;

           while(<$in>)
           {
              s/%%tmp%%/$tmpMisc/;
              s/%%type%%/$script_type/;
              s/%%allowstandby%%/$allowStby/;
              if ($_ =~ /%%TABLESPACES%%/)
              {
                 my @tbs = split(/,/, $tablespace_str);
                 foreach (@tbs)
                 {
                    print $prepout "$_,\n";
                 }
                 print $prepout "NULL\n";
              }
              else
              {
                 print $prepout "$_";
              }
           }

           close $in;
           close $prepout;

           ## Reset tablespace string
           $tablespace_str  = "";

           ## Substitution ends here and xttdetnewfromscnsrc.sql generated

           $output = `sqlplus -L -s $sql_src_connstr \@$prepNextFromScnSql`;
           checkError ("Error in executing $prepNextFromScnSql", $output);

           my @line = split /\n/, $output;

           foreach my $line (@line)
           {
             print XTTNEWPLAN $line . "\n";
           }
        }
        elsif ($option == NEWPLAN)
        {
           ## Subst. for tablespace names

           Mylog("Prepare newscn for Tablespaces: $tablespace_str");

           ## Open the pareparesrc.sql file and substitute all the parameters
           my $prepNextIter = "$tmpMisc/xttpreparenextiter.sql";
           open my $prepout, ">$prepNextIter" or die $!;

           while(<$in>)
           {
              s/%%tmp%%/$tmpMisc/;
              s/%%type%%/$script_type/;
              s/%%allowstandby%%/$allowStby/;
              if ($_ =~ /%%TABLESPACES%%/)
              {
                 my @tbs = split(/,/, $tablespace_str);
                 foreach (@tbs)
                 {
                    print $prepout "$_,\n";
                 }
                 print $prepout "NULL\n";
              }
              else
              {
                 print $prepout "$_";
              }
           }

           close $in;
           close $prepout;

           ## Reset tablespace string
           $tablespace_str  = "";

           ## Substitution ends here and xttpreparenextiter.sql generated

           $output = `sqlplus -L -s $sql_src_connstr \@$prepNextIter`;
           checkError ("Warnings found in executing $prepNextIter", $output);
        }
     }
   }
   if (($option == PREPARE) || ($option == BACKUP) || 
       ($option == GETFILE) || ($option == FIXNEWDFGET))
   {
      close (XTTPLAN);
      if ($option == PREPARE)
      {
         close (RMANCONVERT);
      }
      # If a new datafile or tablespace is added we need to create a new sql
      # file that will be run on the destination.
      elsif ($option == FIXNEWDFGET)
      {
         # Replace the paths with the directory destination objects.
         close (RMANDSTDF);
         fixXTTNewDatafiles (\%dirHash);

         my $transferCount = 0;
         # This file will be used to construct fixnewdf.txt
         my $getfilex = $getfile.".added";
         open GETFILE1, ">$getfilex";
         foreach my $user (sort keys %transfer)
         {
            debug "$user: @{$transfer{$user}}\n";
            foreach my $file (@{$transfer{$user}})
            {
               # Bug 17673476: If the destination file is for ASM, it does not
               # work with automated filenames. So we convert the names here.
               # The automated filenames will be of format "x.y.z". This will
               # converted to "x_y_z"
               my $srcFile;
               my $destFile;
               my $srcPath;
               my $dstPath;

               if ($file =~ m/(.*)\/(.*)/)
               {
                  $srcFile = $2;
                  $srcPath = $dirHash{"$1"}->{"SRC"};
                  $dstPath = $dirHash{"$1"}->{"DST"};
               }
               if ($srcFile =~ m/(.*)\.([0-9]+)\.([0-9]+)/)
               {
                  $destFile = "$1_$2_$3";
               }
               else
               {
                  $destFile = $srcFile;
               }

               print GETFILE1
                     "$transferCount,$srcPath,$srcFile,$dstPath,$destFile\n";
            }
            $transferCount = $transferCount + 1;
         }
         close GETFILE1;
      }
      elsif ($option == GETFILE)
      {
         close (RMANDSTDF);

         # Replace the paths with the directory destination objects.
         fixXTTNewDatafiles (\%dirHash);

         # Ver: 1.4.1 We will generate the SQL file in the destination.
         my $transferCount = 0;

         open GETFILE1, ">$getfile";
         foreach my $user (sort keys %transfer)
         {
            debug "$user: @{$transfer{$user}}\n";
            foreach my $file (@{$transfer{$user}})
            {
               # Bug 17673476: If the destination file is for ASM, it does not
               # work with automated filenames. So we convert the names here.
               # The automated filenames will be of format "x.y.z". This will
               # converted to "x_y_z"
               my $srcFile;
               my $destFile;
               my $srcPath;
               my $dstPath;

               if ($file =~ m/(.*)\/(.*)/)
               {
                  $srcFile = $2;
                  $srcPath = $dirHash{"$1"}->{"SRC"};
                  $dstPath = $dirHash{"$1"}->{"DST"};
               }
               if ($srcFile =~ m/(.*)\.([0-9]+)\.([0-9]+)/)
               {
                  $destFile = "$1_$2_$3";
               }
               else
               {
                  $destFile = $srcFile;
               }

               print GETFILE1
                     "$transferCount,$srcPath,$srcFile,$dstPath,$destFile\n";
            }
            $transferCount = $transferCount + 1;
         }
         close GETFILE1;
      }
      elsif ($option == BACKUP)
      {
         close (RMANDSTDF);

         # Replace the paths with the directory destination objects.
         fixXTTDupDatafiles (\%dirHash);
      }
   }
   elsif ($option == BCKPINCR)
   {
      close (XTTNEWPLAN);
   }

   if ($metaTransfer)
   {
      my @trnsfrFiles = ();
      if ($option == GETFILE)
      {
         push (@trnsfrFiles, "$tmp/xttnewdatafiles.txt");
         push (@trnsfrFiles, "$tmp/getfile.sql");
         transferFiles (@trnsfrFiles);
      }
      if ($option == BCKPINCR)
      {
         if (-e "$tmp/xttplan.txt")
         {
            push (@trnsfrFiles, "$tmp/xttplan.txt");
            transferFiles (@trnsfrFiles);
         }
      }
      if ($option == PREPARE)
      {
         push (@trnsfrFiles, "$tmp/rmanconvert.cmd");
         transferFiles (@trnsfrFiles);
         @trnsfrFiles = ();
         $context->{"desttmp"} = $props{'stageondest'};
         push (@trnsfrFiles, $props{'dfcopydir'}."/*");
         transferFiles (@trnsfrFiles);
         $context -> {"desttmp"} = $props{'desttmpdir'};
      }
      if ($option == BACKUP)
      {
         @trnsfrFiles = ();
         push (@trnsfrFiles, "$tmp/tsbkupmap.txt");
         push (@trnsfrFiles, "$tmp/xttnewdatafiles.txt");
         transferFiles (@trnsfrFiles);

         open FILE, "$tmpMisc/incrbackups.txt";
         @trnsfrFiles = <FILE>;
         close FILE;

         $context->{"desttmp"} = $props{'stageondest'};
         transferFiles (@trnsfrFiles);
         $context -> {"desttmp"} = $props{'desttmpdir'};
      }
   }
}
##
## End generate_batch_tsoutput
##

###############################################################################
# Function : assignGlobVars
# Purpose  : Assign global variables
###############################################################################
sub assignGlobVars
{
   if (! defined($context->{"xttdir"}))
   {
      if (defined($ENV{'TMPDIR'}))
      {
         $tmp = $ENV{'TMPDIR'};
      }
      else
      {
         Die ("TMPDIR not defined");
      }
   }
   else
   {
      $tmp = $context->{"xttdir"};
   }

   # Get the timestamp once so that for entire execution of the script we
   # have a single timestamp. Also create directories into which the temp
   # files will be copied/moved
   $tstamp = GetTimeStamp();
   if ($context->{"backup"})
   {
      $tmpMisc = "$tmp/backup_"."$tstamp/";
   }
   elsif ($context->{"bkpincr"})
   {
      $tmpMisc = "$tmp/bkpincr_"."$tstamp/";
   }
   elsif ($context->{"restore"})
   {
      $tmpMisc = "$tmp/restore_"."$tstamp/";
   }
   elsif ($context->{"recover"})
   {
      $tmpMisc = "$tmp/recover_"."$tstamp/";
   }
   elsif ($context->{"resincrdmp"})
   {
      $tmpMisc = "$tmp/resincrdmp_"."$tstamp/";
   }
   elsif ($context->{"rollforward"})
   {
      $tmpMisc = "$tmp/rollforward_"."$tstamp/";
   }
   elsif ($context->{"determinescn"})
   {
      $tmpMisc = "$tmp/determinescn_"."$tstamp/";
   }
   elsif ($context->{"fixnewdf"})
   {
      $tmpMisc = "$tmp/fixnewdf_"."$tstamp/";
   }
   elsif ($context->{"generate"})
   {
      $tmpMisc = "$tmp/generate_"."$tstamp/";
   }
   elsif ($context->{"bkpexport"})
   {
      $tmpMisc = "$tmp/bkpexport_"."$tstamp/";
   }
   elsif ($context->{"setupgetfile"})
   {
      $tmpMisc = "$tmp/setupgetfile_"."$tstamp/";
   }
   elsif ($context->{"getfile"})
   {
      $tmpMisc = "$tmp/getfile_"."$tstamp/";
   }
   elsif ($context->{"incremental"})
   {
      $tmpMisc = "$tmp/incremental_"."$tstamp/";
   }
   elsif ($context->{"prepare"})
   {
      $tmpMisc = "$tmp/prepare_"."$tstamp/";
   }
   elsif ($context->{"convert"})
   {
      $tmpMisc = "$tmp/convert_"."$tstamp/";
   }
   else
   {
      $tmpMisc = "$tmp/$tstamp/";
   }
   system ("mkdir $tmpMisc");

   $traceLog  = "$tmpMisc/".$tstamp."_.log";
   LogMessageScreen("trace file is $traceLog");
   $xttpath   = "$tmp/xttplan.txt";
   $rmantfrdf = "$tmp/rmantfrdf.sql";
   $rmandstdf = "$tmp/xttnewdatafiles.txt";
   $xttprep   = "$tmpMisc/xttprepare.cmd";
   $rmanpath  = "$tmp/rmanconvert.cmd";
   $errfile   = "$tmp/FAILED";
   $getfile   = "$tmp/getfile.sql";
   $connectstring = "/ as sysdba";
   $sqlSettings =
   "SET TRIMSPOOL OFF LINES 32767 PAGES 0 FEEDBACK OFF ".
   "VERIFY OFF DEFINE \"&\" TERMOUT OFF";
   $compFile   = "$tmp/dfcomp.txt";
   $dfLck = "$tmp/dffailed.lck";
   $dfCopyFile = "$tmp/dfcopy.txt";
   $failedDf   = "$tmp/dffailed.txt";
   $tsbkupmap = "$tmp/tsbkupmap.txt";
   $tsbkupmapWhole = "$tmp/tsbkupmapwhole.txt";
   $resFile = "$tmp/res.txt";

   $xttplan = "$tmp/xttplan.txt";
   $xttplanNew = "$tmp/xttplan.txt.new";
   $xttnew = "$tmp/xttnewdatafiles.txt";
   $tbsMap = "$tmp/tsbkupmap.txt";
   $newfileAdded = "$tmp/newfile.txt";
}

###############################################################################
# Function : checkMove
# Purpose  : Check if entry is present and move it
###############################################################################
sub checkMove
{
   my $srcPath = $_[0];
   my $dstPath = $_[1];

   if (!$dstPath)
   {
      $dstPath = $tmpMisc;
      if ($srcPath =~ m/.*\/(.*)/)
      {
         $dstPath = $dstPath."/".$1;
         if ((-e $dstPath) && (-e $srcPath))
         {
            system("\\mv $dstPath $dstPath".$tstamp);
         }
      }
   }

   if (-e $srcPath)
   {
      system("\\mv $srcPath $dstPath");
   }
}

###############################################################################
# Function : checkCopy
# Purpose  : Check if entry is present and copy it
###############################################################################
sub checkCopy
{
   my $srcPath = $_[0];
   my $dstPath = $_[1];

   if (!$dstPath)
   {
      $dstPath = $tmpMisc;
      if ($srcPath =~ m/.*\/(.*)/)
      {
         $dstPath = $dstPath."/".$1;
         if ((-e $dstPath) && (-e $srcPath))
         {
            system("\\mv $dstPath $dstPath".$tstamp);
         }
      }
   }

   if (-e $srcPath)
   {
      system("\\cp $srcPath $dstPath");
   }
}

###############################################################################
# Function : fixXTTDestFile
# Purpose  : Fix the destination file by replacing the tag DESTDIR with the
#            actual location
###############################################################################
sub fixXTTDestFile
{
   my $replaceFile = 0;
   my @destArray = ();
   my %dirHash;

   open(RMANDSTDF, "$rmandstdf") ||
      Die "Cant find $rmandstdf";
   @destArray = <RMANDSTDF>;
   close RMANDSTDF;

   foreach my $line (@destArray)
   {
      if (($line !~ m/::.*/) && ($line =~ m/.*\:.*/))
      {
         $replaceFile = 1;
         last;
      }
   }

   my $rmandstdfT = "$tmpMisc/xttnewdatafiles_".$tstamp.".txt";
   if ($replaceFile)
   {
      &fetchCheckDirObjectsDST($props{'dstdir'}, "", \%dirHash);
      open(RMANDSTDF1, ">$rmandstdfT") ||
         Die "Cant find $rmandstdfT";
      foreach my $line (@destArray)
      {
         if (($line !~ m/::.*/) && ($line =~ /.*,(.*):.*/))
         {
            my $tempDir = $1;
            $line =~ s/$tempDir:/$dirHash{"$tempDir"}/;
         }
         if ($line =~ m/(.*)\/(.*)\.([0-9]+)\.(.*)/)
         {
            $line = "$1/$2_$3_$4\n";
         }
         print RMANDSTDF1 "$line";
      }
      close RMANDSTDF1;
      checkMove("$rmandstdf");
      checkCopy($rmandstdfT, $rmandstdf)
   }
}

###############################################################################
# Function : restoreNewDf
# Purpose  : Restore the new datafiles
###############################################################################
sub restoreNewDf
{
   my $tsbkupmapDf = $_[0];
   my $tsbkupmap = "$tmp/tsbkupmap.txt";

   LogMessage ("Restoring newly added datafiles");

   checkMove($tsbkupmap);
   checkCopy($tsbkupmapDf, $tsbkupmap);
   
   $context->{"platname"} = getPlatName();
   fixXTTDestFile();
   resrecBkp(RESTORE);

   LogMessage ("Completed getting datafiles from source");
}

###############################################################################
# Function : getFilesSource
# Purpose  : Get files from the source database.
###############################################################################
sub getFilesSource
{
   my $getfile = $_[0];
   LogMessage ("Getting datafiles from source");

   my $output;
   my $connectstringcnvinst;
   my $pid;
   my @getArray = ();
   my $getFileTemp;

   &checkDbLink($props{'srclink'});

   fixXTTDestFile();

   $connectstringcnvinst = "/ as sysdba";

   open FILE, "$getfile" or Die ("Cannot open $getfile");;
   @getArray =  <FILE>;
   close FILE;

   foreach my $x (@getArray)
   {
      chomp ($x);
      if ($x =~ m/(.*?),(.*?),(.*?),(.*?),(.*)/)
      {
         my $sqlQuery =
                 "BEGIN
                  DBMS_FILE_TRANSFER.GET_FILE(
                  source_directory_object      => '".$2."',
                  source_file_name             => '".$3."',
                  source_database              => '".$props{'srclink'}."',
                  destination_directory_object => '".$4."',
                  destination_file_name        => '".$5."');
                  END;
                  /
                  ";

         $getFileTemp = "getfile"."_$2"."_$3"."_$1".".sql";
         $getFileTemp = lc ($getFileTemp);
         $getFileTemp = "$tmpMisc/$getFileTemp";
         open FILE, ">$getFileTemp";
         print FILE "$sqlQuery\nquit\n";
         close FILE;

         ChecktoProceed($getParallel);
         $pid = fork();

         if ($pid == 0)
         {
            LogMessage ("Executing getfile for $getFileTemp");
            $output =  `sqlplus -L -s \"$connectstringcnvinst\" \@$getFileTemp`;
            checkError ("Error in executing $getFileTemp", $output);
            Unlink ($getFileTemp);
            exit (0);
         }
         else
         {
            UpdateForkArray ($pid, $getParallel);
         }
      }
   }

   while((my $pid = wait()) > 0)
   {
      #sleep (1);
   }

   LogMessage ("Completed getting datafiles from source");
}

###############################################################################
# Function : prepare
# Purpose  : Initial preparation for script to run.
###############################################################################
sub prepare
{
   ###
   ### Prepare starts here
   ###

   LogMessage ("Starting prepare phase");

   # Check if any failure occured and stop exection
   checkErrFile();

   ## Perform cleanup of files by renaming the xttplan.txt, rmanconvert.cmd
   ## and xttprep.cmd (datafile copy)
   checkMove($xttpath);
   checkMove($rmanpath);
   checkMove($xttprep);

   ## For each tablespace, lets generate the scripts
   my $stageondest   = $props{'stageondest'};
   my $platform      = "'$props{'platform'}'";
   my $storageondest = $props{'storageondest'};
   my $dfcopydir     = $props{'dfcopydir'};

   debug "Parallel:" . $props{'parallel'};

   ## Remove trailing '/'s
   $dfcopydir = $1 if($dfcopydir=~/(.*)\/$/);
   ## Check if previous ".tf" files present.
   ##
   my @present = glob("$dfcopydir/*.tf");

   if (@present)
   {
      ## Try deleting any existing copied datafiles
      system("\\rm -f $dfcopydir/*.tf");
      sleep 5;
   }

   if ($context->{"setupgetfile"})
   {
      &fetchCheckDirObjectsSRC($props{'srcdir'}, "", \%dirHash);

      foreach my $keys (keys %dirHash)
      {
         debug4 "prepare: Key is $keys\n";
         debug4 "prepare: Value is ".$dirHash{"$keys"}."\n";
      }
      &generate_batch_tsoutput(GETFILE);
   }
   elsif ($context->{"backup"})
   {
      &generate_batch_tsoutput(BACKUP);
   }
   else
   {
      &generate_batch_tsoutput(PREPARE);
   }

   LogMessage ("Done with prepare phase");
   Unlink($resFile);
   genResFile();
   fixResFile();
   copyResFile();
   newplan();
}

sub prepare12C
{
   ###
   ### Prepare starts here
   ###

   LogMessage ("Starting backup phase");

   # Check if any failure occured and stop exection
   checkErrFile();

   ## Perform cleanup of files by renaming the xttplan.txt, rmanconvert.cmd
   ## and xttprep.cmd (datafile copy)
   checkMove($xttpath);
   checkMove($rmanpath);
   checkMove($xttprep);

   ## For each tablespace, lets generate the scripts
   my $stageondest   = $props{'stageondest'};
   my $platform      = "'$props{'platform'}'";
   my $storageondest = $props{'storageondest'};
   my $dfcopydir     = $props{'dfcopydir'};

   debug "Parallel:" . $props{'parallel'};

   ## Remove trailing '/'s
   $dfcopydir = $1 if($dfcopydir=~/(.*)\/$/);
   ## Check if previous ".tf" files present.
   ##
   my @present = glob("$dfcopydir/*.tf");

   if (@present)
   {
      ## Try deleting any existing copied datafiles
      system("\\rm -f $dfcopydir/*.tf");
      sleep 5;
   }

   &generate_batch_tsoutput(BACKUP);

   LogMessage ("Done with backup phase");
   Unlink($resFile);
   genResFile();
   copyResFile();
   fixResFile();
   newplan();
   checkAddDFilesBackup12C();
}

###############################################################################
# Function : prepare
# Purpose  : Initial preparation for script to run.
###############################################################################
sub prepare11G
{
   ###
   ### Prepare starts here
   ###

   LogMessage ("Starting prepare phase");

   # Check if any failure occured and stop exection
   checkErrFile();

   ## Perform cleanup of files by renaming the xttplan.txt, rmanconvert.cmd
   ## and xttprep.cmd (datafile copy)
   checkMove($xttpath);
   checkMove($rmanpath);
   checkMove($xttprep);

   ## For each tablespace, lets generate the scripts
   my $stageondest   = $props{'stageondest'};
   my $platform      = "'$props{'platform'}'";
   my $storageondest = $props{'storageondest'};
   my $dfcopydir     = $props{'dfcopydir'};

   debug "Parallel:" . $props{'parallel'};

   ## Remove trailing '/'s
   $dfcopydir = $1 if($dfcopydir=~/(.*)\/$/);
   ## Check if previous ".tf" files present.
   ##
   my @present = glob("$dfcopydir/*.tf");

   if (@present)
   {
      ## Try deleting any existing copied datafiles
      system("\\rm -f $dfcopydir/*.tf");
      sleep 5;
   }

   getxttnewdf();
   &generate_batch_tsoutput(PREPARE);

   LogMessage ("Done with prepare phase");
   Unlink($resFile);
   genResFile();
   copyResFile();
   newplan();
   checkAddDFilesPrepare();
}

###############################################################################
# Function : checkExec
# Purpose  : Check if the rman and sqlplus executables are present in path
###############################################################################
sub checkExec
{
   if (defined ($context->{"orahome"}))
   {
      $ENV{'ORACLE_HOME'} = $context->{"orahome"};
   }
   else
   {
      if (defined ($ENV{'ORACLE_HOME'}))
      {
         $context->{"orahome"} = $ENV{'ORACLE_HOME'};
      }
      else
      {
         Die ("Niether ORACLE_HOME defined or orahome passed to script") ;
      }
   }

   if (defined ($context->{"orasid"}))
   {
      $ENV{'ORACLE_SID'} = $context->{"orasid"};
   }
   else
   {
      if (defined ($ENV{'ORACLE_SID'}))
      {
         $context->{"orasid"} = $ENV{'ORACLE_SID'};
      }
      else
      {
         Die ("Niether ORACLE_SID defined or orasid passed to script") ;
      }
   }

   debug "ORACLE_SID  : $context->{\"orasid\"}";
   debug "ORACLE_HOME : $context->{\"orahome\"}";

   $ENV{'PATH'} = "$context->{\"orahome\"}/bin".":".$ENV{'PATH'};
   $context->{'sqlexec'}   = "$context->{\"orahome\"}/bin/sqlplus";
   $context->{'rmanexec'}  = "$context->{\"orahome\"}/bin/rman";

   if (! -x $context->{"rmanexec"})
   {
      Die ("RMAN executable not found in path");
   }

   if (! -x $context->{"sqlexec"})
   {
      Die ("SQLPLUS executable not found in path");
   }
}

###############################################################################
# Function : checkArg
# Purpose  : check if given arguments are fine
###############################################################################
sub checkArg
{
   if ($context->{"backup"} || $context->{"bkpincr"} ||
       $context->{"bkpexport"} || $context->{"restore"} ||
       $context->{"recover"} || $context->{"resincrdmp"})
   {
      # Bug 22352281: Get the platform name only during 
      # restore or recover
      if ($context->{"restore"} || $context->{"recover"} || 
          $context->{"resincrdmp"})
      {
         $context->{"platname"} = getPlatName();
      }
      my $ver = checkCompat();
      if (0 && $ver < VER12)
      {
         Warn("Unable to use given option with this version of DB. Min ver".
              " required is 12.1.0.0");
      }
   }
   if ($context->{"prepare"})
   {
      if (defined($props{'srcdir'}) ||
          defined($props{'dstdir'}) ||
          defined($props{'srclink'}))
      {
         Die ("Make sure srcdir dstdir srclink is not defined with prepare");
      }
   }
   if ($context->{"backup"} || $context->{"bkpincr"} ||
       $context->{"bkpexport"} || $context->{"setupgetfile"} ||
       $context->{"prepare"})
   {
      checkStandby();
   }
}

###############################################################################
# Function : copyImpfiles
# Purpose  : Copies all the important files
###############################################################################
sub copyImpfiles
{
   foreach my $x(@impXTTFiles)
   {
      checkCopy("$tmp/$x");
   }
}

sub performBackup11GLevel0
{
   prepare11G();
}

sub performBackup11GLevel1
{
   backincr();
}

sub performBackup12GLevel0
{
   prepare12C();
}

sub performBackup12GLevel1
{
   backincr();
}

sub performBackup11G
{
   if (!-e $resFile)
   {
      performBackup11GLevel0();
   }
   else
   {
      performBackup11GLevel1();
   }
}

sub performBackup12C
{
   if (!-e $resFile)
   {
      performBackup12GLevel0();
   }
   else
   {
      performBackup12GLevel1();
   }
}

###############################################################################
# Function : Main
# Purpose  : Main entry point for the program
###############################################################################
sub Main
{
   parseArg();
   assignGlobVars();

   # User wanted to clear file, do it so here
   if ($context->{"clearerrorfile"})
   {
      Unlink ($errfile, 1);
   }

   parseProperties();
   checkProps();
   checkExec();
   checkArg();
   copyImpfiles();

   #If we want specify tablespaces to be rolled forward, then store them in
   #a hash
   checkCopy($resFile);

   if ($context->{"rolltbs"})
   {
      @rolltbsArray = split (',', $context->{"rolltbs"});
      foreach my $x (@rolltbsArray)
      {
         $tbsHash{"$x"}= 1;
      }
   }

   if (($context->{"incremental"}) ||
       ($context->{"bkpincr"}) ||
       ($context->{"bkpexport"}))
   {
      backincr();
   }
   elsif ($context->{"rollforward"})
   {
      fixXTTDestFile();
      rollforward();
   }
   elsif ($context->{"restore"})
   {
      if (defined($props{'usefiletransfer'}))
      {
         performConvert11G();
      }
      elsif (defined($props{'usermantransport'}))
      {
         debug "Doiung 12C\n";
         performRes12C();
      }
      else
      {
         performRes11G();
      }
   }
   elsif (($context->{"recover"}) ||
          ($context->{"resincrdmp"}))
   {
      fixXTTDestFile();
      resrecBkp(RECOVER);
      if ($context->{"resincrdmp"} || ($context->{"includeimport"}))
      {
         createDumpFile();
         plugin(LOCALFILE);
      }
   }
   elsif ($context->{"determinescn"})
   {
      newplan();
   }
   elsif ($context->{"convert"})
   {
      #If the transfer is across the same endian then platformid will be
      #set as 0.
      if ($props{'platformid'} == 0)
      {
         genConvertDFNames();
      }
      else
      {
         convert();
      }
   }
   elsif ($context->{"fixnewdf"})
   {
      fixNewDatafiles();
   }
   elsif ($context->{"generate"})
   {
      plugin(LINK);
   }
   elsif ($context->{"backup"})
   {
      if (defined($props{'usefiletransfer'}))
      {
         performConvert11G();
      }
      elsif (defined($props{'usermantransport'}))
      {
         debug "XXX: Doing usermantransport\n";
         performBackup12C();
      }
      else
      {
         performBackup11G();
      }
   }
   elsif (($context->{"prepare"}) || ($context->{"backup"}))
   {
      checkNoPwdSSHEnabled ();
      prepare();
      getxttnewdf();
   }
   elsif ($context->{"setupgetfile"})
   {
      checkNoPwdSSHEnabled ();
      prepare();
   }
   elsif ($context->{"getfile"})
   {
      getFilesSource($getfile);
   }
   else
   {
      usage();
   }
   copyImpfiles();
}

###
### Incremental Starts here
###

## Generates <TMPDIR>/tsbkupmap.txt
## that maps tablespace to backup

sub gentablespace_backupmap
{
   my @line = split /\n/, $_[0];

   my $tsbkupmap = "$tmp/tsbkupmap.txt";
   my $incrbkups = "$tmpMisc/incrbackups.txt";

   my $backupformat = $props{'backupformat'};
   my $i = 0;
   my @fnums = ();
   my @fnumorder = ();
   my $chan;
   my %bpfn;
   my %bpts;
   my %chfn;
   my $tsname;
   my $fno;
   my $order = 0;
   my $dmpFile = 0;

   open(TSBKMAP, ">>$tsbkupmap") ||
      Die("Cant open tablespace backup map file $!");
   open(INCRBKUPS, ">>$incrbkups") || Die("Cant open incr backups file $!");


   while ($i <= $#line)
   {
      my $str = $line[$i];

      if ($str =~ /^ts::(.*)$/)
      {
         $tsname = $1;
         $order = 0;
      }
      elsif ($str =~ /channel (.*): specifying datafile/)
      {
        $chan = $1;
      }
      elsif ($str =~ /.*input Data Pump dump file.*/)
      {         ## piece name is on the next line
         $i++;
         $str = $line[$i];
         $chan = $1;
         $dmpFile = 1;
      }
      ## In HP, an issue was reported where in the RMAN output was
      ## shown as 'input datafile fno' instead of 'input datafile file number'.
      ## So parse for both here.
      elsif (($str =~ /input datafile file number=(\d+) name/) ||
             ($str =~ /input datafile fno=(\d+) name/))
      {
         $fno = $1 + 0;
         push(@fnums, $fno);
         $i++;
         if ($rmanLog)
         {
            $order = 0;
         }
         next;
      }
      elsif (defined($chan) && $#fnums >= 0)
      {
         my @new = @fnums;
         $chfn{$chan} -> {"fnumarray"} = \@new;
         @fnums = ();
      }
      elsif ($str =~ /channel (.*): finished piece/)
      {
         ## piece name is on the next line
         $i++;
         $str = $line[$i];

         $chan = $1;

         # This will be modified once we support rman logging
         if ($str =~ /.*piece handle=(.+)[\/](\S+) tag=TG(.*)_TG comment=.*/)
         {
            if ($rmanLog)
            {
               $tsname = $3;   
            }
            if ($dmpFile)
            {
               my $piece = $2;
               debug "backup piece:" . $piece . "\n" ;
               print TSBKMAP "DMPEXP::$piece\n";
               print INCRBKUPS $backupformat."/$piece \n";
            }
            else
            {
               $bpfn{$2} -> {"fnumarray"} = $chfn{$chan} -> {"fnumarray"};
               $order = $order + 1;
               $bpfn{$2} -> {"fnumorder"} = $order;
               $bpts{$2} = $tsname;
            }
         }
         elsif ($str =~ /piece handle=(.+)[\/](\S+) tag/)
         {
            if ($rmanLog)
            {
               $tsname = $3;   
            }
            if ($dmpFile)
            {
               my $piece = $2;
               debug "backup piece:" . $piece . "\n" ;
               print TSBKMAP "DMPEXP::$piece\n";
               print INCRBKUPS $backupformat."/$piece \n";
            }
            else
            {
               $bpfn{$2} -> {"fnumarray"} = $chfn{$chan} -> {"fnumarray"};
               $order = $order + 1;
               $bpfn{$2} -> {"fnumorder"} = $order;
               $bpts{$2} = $tsname;
            }
         }
      }
      elsif ($str =~ /including current control file in backup set/)
      {
        do
        {
           $i++;
           $str = $line[$i];
        }
        while ($str !~ /Finished backup/);
      }

      $i++;
   }

   foreach my $pkey (keys %bpfn)
   {
      print INCRBKUPS $backupformat . "/$pkey\n";
      my @fns = @{$bpfn{$pkey} -> {"fnumarray"}};
      my $sizefns = @fns;

      print TSBKMAP $bpts{$pkey} . "::";

      my $orderx = $bpfn{$pkey} -> {"fnumorder"};
      foreach my $v (@fns)
      {
         $sizefns--;
         print TSBKMAP $v;
         print TSBKMAP "," if ($sizefns > 0);
      }

      print TSBKMAP ":::".  $orderx;
      print TSBKMAP "=" .  $pkey;
      print TSBKMAP "\n";
   }
   close(TSBKMAP);
   close(INCRBKUPS);

   my @tsArray = ();
   open FILE, "$tsbkupmap";
   @tsArray = <FILE>;
   close FILE;
   my $sizeA = @tsArray;   

   if($sizeA == 0)
   {
      LogMessage ("No backups were formed");
   }

   checkCopy($incrbkups, "$tmp/incrbackups.txt");
}

###############################################################################
# Function : appendXttPlan
# Purpose  : Add given tablespace entries to xttplan.txt
###############################################################################
sub appendXttPlan
{
   my $tsHashP = shift;
   my %tsHash = %$tsHashP;
   my $xttplan = "$tmp/xttplan.txt";
   my @existArray = ();
   my @tsArray = ();

   if (!-e $xttplan)
   {
      Die("Unable to find $xttplan, check if -s was run");
   }

   open FILE, "$xttplan";
   @existArray = <FILE>;
   close FILE;

   foreach my $x (@existArray)
   {
      if ($x =~ m/(.*)::::(.*)/)
      {
         $x = trim($1);
         push(@tsArray,$x);
      }
   }

   open FILE, ">>$xttplan";
   foreach my $keys (keys %tsHash)
   {
      debug "XXX: keys: $keys\n";
      if (!CheckEleExists (\@tsArray,$keys))
      {
         debug "XXX: writing keys: $keys\n";
         print FILE $keys."::::".$tsHashP->{"$keys"}->{"scn"}."\n";
         foreach my $x (@{$tsHashP->{"$keys"}->{"files"}})
         {
            print FILE "$x\n";
         }
      }
      else
      {
         debug "XXX: ignorning keys\n";
         debug3 ("Ignoring $keys");
      }
   }
   close FILE;
}

sub splitTBSString
{
   my $str = $_[0];
   chomp ($str);
   my @original = split (/,/,$str);
   my $empty = '\'\'';
   $numTbArrays = int scalar(@original)/1000 + 2;
   print "scalar(or".scalar(@original)."\n";
   if (scalar(@original) == 1)
   {
      $numTbArrays = 1;
   }

   foreach my $x (0..$numTbArrays-1)
   {
      if ($tbsArrayRef[$x])
      {
         @{$tbsArrayRef[$x]} = undef;
      }
   }

   while (@original) 
   {
      foreach my $y (0..$numTbArrays-1)
      {
         if (@original) 
         {
            my $x = shift @original;
            $x = trim($x);
            if ($y == ($numTbArrays-1))
            {
               $x = '\''.$x.'\'' . chr(10) . ',';
            }
            else
            {
               $x = '\''.$x.'\'' . chr(10) . ',';
            }
            push @{$tbsArrayRef[$y]}, $x;
         }
      }
   }

   print "XXX: adding here for $numTbArrays, ".scalar(@original).", $str\n";
   foreach my $x (0..$numTbArrays-1)
   {
      if (!@{$tbsArrayRef[$x]})
      {
         debug "XXX: adding here for index $x\n";
         push(@{$tbsArrayRef[$x]}, $empty);
      }
      else
      {
         my $last = pop(@{$tbsArrayRef[$x]});
         debug "XXX: adding proper here for index $x, b4 added $last\n";
         $last =~ s/[,\r\n]/ /g; 
         debug "XXX: adding proper here for index $x, added $last\n";
         if ($last ne '')
         {
            push(@{$tbsArrayRef[$x]}, $last);
         }
         else
         {
            push(@{$tbsArrayRef[$x]}, $empty);
         }
      }
   }
   #exit (0);
}

###############################################################################
# Function : getXTTNewOld
# Purpose  : Reading existing xttnewdatafiles.txt and also creates a new 
#            xttnewdatafiles.txt.added which has all the datafiles, tablespaces.
#            This will be compared to find newly added tablespaces and 
#            datafiles.
###############################################################################
sub getXTTNewOld
{
   my @sqlOutput;
   my @xttOut = ();

   my $xttnew = "$tmpMisc/xttnewdatafiles.txt.added";
   my $xttorg = "$tmp/xttnewdatafiles.txt";
   my $sqlfile = "$tmpMisc/diff.sql";
   my $tsbkmap = "$tmp/tsbkupmap.txt";
   my $incrbkups = "$tmpMisc/incrbackups.txt";

   checkMove($tsbkmap);
   checkMove($incrbkups);
   splitTBSString($props{'tablespaces'});

   if (!-e $xttorg)
   {
      LogMessageScreen("$xttorg not present, so can't check if new files got".
                         " added");
      return;
   }
   else
   {
      checkCopy($xttorg);
   }
   
   open FILE, ">$sqlfile";
   print FILE << "EOF";
SET TRIMSPOOL ON TAB OFF PAGES 0 EMB OFF LINES 32767 FEEDBACK OFF SERVEROUTPUT ON FORMAT TRUNCATE COLSEP "" RECSEP OFF DEFINE "&" VERIFY OFF
SELECT CASE
         WHEN rn = 1
         THEN '::' || ts_name || ':::SCN:::' || ckpn || CHR(10) 
       END
    || file#
    || '='
    || ckpn
    || ','
    || ts_name
    || ','
    || df_name
  FROM (
SELECT ROW_NUMBER() OVER (PARTITION BY t.name ORDER BY d.file#) rn
     , t.ts#
     , t.name ts_name
     , d.file#
     , '&1' || '/' || t.name || '_' || d.file# || '.dbf' df_name
     , checkpoint_change# ckpn
  FROM v\$tablespace t
     , v\$datafile d
 WHERE t.ts# = d.ts#
   AND (
EOF
   my $x = 0;
   debug ("Number of tb arrays is $numTbArrays\n");
   for ($x = 0 ; $x < $numTbArrays - 1; $x = $x + 1)
   {
   print FILE << "EOF";
       t.name IN (@{$tbsArrayRef[$x]}) OR 
EOF
   }
   print FILE << "EOF";
       t.name IN (@{$tbsArrayRef[$x]})
       )
       )
 ORDER BY
       ts#
     , ckpn
     , file#
/
EXIT
EOF
   close FILE;
   my $cmdStr = "sqlplus -L -s $sql_src_connstr \@$sqlfile ".
                $props{'storageondest'};

   my $sqlOutputStr = `$cmdStr`;
   @sqlOutput = split /\n/, $sqlOutputStr;

   checkError ("Error in executing getXTTNewOld", $sqlOutputStr);

   debug3(@sqlOutput);

   open FILE, ">$newfileAdded";
   foreach my $x (@sqlOutput)
   {
      debug3("$newfileAdded: $x");
      $x = trim($x);
      print FILE "$x\n";
   }
   close FILE;

   open FILE, ">$xttnew";
   foreach my $x (@sqlOutput)
   {
      debug3("$xttnew: $x");
      chomp($x);
      if ($x =~ /^(.*):::SCN:::(.*)$/)
      {
         print FILE "$1\n";
      }
      else
      {
         debug "Writing new $x\n";
         if ($x =~ m/(.*?)=(.*?),(.*?),(.*)/)
         {
            debug "Writing1 new $1, $4\n";
            print FILE "$1,$4\n";
         }
      }
   }
   close FILE;
   
   open FILE, "$xttorg";
   @xttOut = <FILE>;
   close FILE;
   
   return (\@xttOut, \@sqlOutput);
}

sub fixSlashName
{
   my $fname = $_[0];
   $fname =~ s/\/\//\//g;

   return $fname;
}

###############################################################################
# Function : checkAddDFilesBackup12C
# Purpose  : See if any news files were added when using 12C "for transport"
#            method.
#            The logic is as follows. Find all the list of datafiles for the 
#            given set of tablespaces. See if they are already part of 
#            xttnewdatafiles.txt
###############################################################################
sub checkAddDFilesBackup12C
{
   my @sqlOutput ;
   my @xttOut = ();
   my $tsName = '';
   my %dfHash;
   my %tsHash;
   my $dfHashP = \%dfHash;
   my $tsHashP = \%tsHash;
   my $xttnew = "$tmpMisc/xttnewdatafiles.txt.added";
   my $xttorg = "$tmp/xttnewdatafiles.txt";
   my $sqlfile = "$tmpMisc/diff.sql";
   my $tsbkmap = "$tmp/tsbkupmap.txt";
   my $incrbkups = "$tmpMisc/incrbackups.txt";

   my ($xttOutR, $sqlOutputR) = getXTTNewOld();

   @xttOut = @$xttOutR;
   @sqlOutput = @$sqlOutputR;

   foreach my $x(@xttOut)
   {
      debug3("XTTout:".$x);
      chomp($x);
      if ($x =~ /^::(.*)$/)
      {
         $tsName = $1;
         $tsHashP->{"$tsName"}->{"tsname"} = $tsName;
         $tsHashP->{"$tsName"}->{"scn"} = 0;
      }
      elsif ($x =~ /(.*),(.*)$/)
      {
         my $fno = $1;
         my $fname = $2;
         $dfHashP->{"$1"}->{"tsname"} = $tsName;
         if ($fname =~ m/.*\/(.*)..*/)
         {
            $dfHashP->{"$fno"}->{"fname"} = 
               $props{'stageondest'}."/$1.tf";
         }
      }
   }
   
   my @printFArray = ();
   my @tsArray = ();
   my $scn = 0;

   foreach my $x(@sqlOutput)
   {
      debug3("Sqlout:".$x);
      chomp($x);
      if ($x =~ /^::(.*):::SCN:::(.*)$/)
      {
         $scn = $2;
         $tsName = $1;
         my @fstArray = ();
         if (defined($tsHashP->{"$tsName"}->{"tsname"}))
         {
            delete $tsHashP->{"$tsName"};
         }
         else
         {
            $tsHashP->{"$tsName"}->{"scn"} = $scn;
            $tsHashP->{"$tsName"}->{"tsname"} = $tsName;
            $tsHashP->{"$tsName"}->{"files"} = [@fstArray];
         }
      }
      elsif ($x =~ /(.*)=.*?,.*?,(.*)$/)
      {
         my $fno = $1;
         my $fname = $2;
         if (defined($dfHashP->{"$fno"}->{"tsname"}))
         {
            delete $dfHashP->{"$fno"};
         }
         else
         {
            $dfHashP->{"$1"}->{"tsname"} = $tsName;
            $fname = fixSlashName($fname);
            if ($fname =~ m/.*\/(.*).dbf/)
            {
               my $printFStr = "$1.tf";
               $dfHashP->{"$fno"}->{"fname"} = 
                  $props{'stageondest'}."/".$printFStr;
               push (@printFArray, $printFStr);
               my @fstArray = ();
               if (defined($tsHashP->{"$tsName"}))
               {
                  if (@{$tsHashP->{"$tsName"}->{"files"}})
                  {
                     @fstArray = @{$tsHashP->{"$tsName"}->{"files"}};
                  }
                  push(@fstArray, $fno);
                  $tsHashP->{"$tsName"}->{"files"} = [@fstArray];
               }   
            }
         }
      }
   }

   @printFArray = join(',', @printFArray);

   my @fileArray = keys %dfHash;
   my $fcount = scalar @fileArray;
   if ($fcount == 0)
   {
      debug("No new datafiles added");
      return;
   }
   @fileArray = join(',', @fileArray);
   LogMessageScreen("@fileArray $fcount new datafiles added");
   
   my $platName = getCurrPlatName();

   my $prepCmd = "backup for transport allow inconsistent incremental ".
                 "level 0 datafile ".
                 "@fileArray format '".
                 $props{'backupformat'}."/%N_%f_%U.bkp';";
                                         
   #print $prepCmd."\n";
   
   my $newprepFile = "$tmpMisc/prepare".$tstamp.".cmd";
   open FILE, ">$newprepFile";
   print FILE $prepCmd."\n";
   close FILE;

   my $fixNewDf = "$tmp/fixnewdf.txt";
   open FILE, ">$fixNewDf";
   print FILE "STARTXTTNEW\n";
   foreach my $x(@sqlOutput)   
   {
      chomp($x);
      print FILE "$x\n";
   }
   print FILE "ENDTXTTNEW\n";
   close FILE;
   
   LogMessageScreen("Running backup cmd for new files @printFArray");

   my $output = `rman target $rman_src_connstr cmdfile $newprepFile`;
   
   debug $output."\n";

   if ($output =~ /ERROR MESSAGE/)
   {
      Die("$output $!");
   }
   &gentablespace_backupmap($output);

   my @tsbkArr;
   open FILE1, $tsbkmap;
   @tsbkArr = <FILE1>;
   close FILE1;

   $fixNewDf = "$tmp/fixnewdf.txt";
   open  FILE, ">>$fixNewDf";
   print FILE "STARTCONV::".BACKUP."\n";

   foreach my $x (@tsbkArr)   
   {
      chomp($x);
      print FILE "$x\n";
   }

   print FILE "ENDCONV\n";
   close FILE;

   checkCopy($xttnew, $xttorg);

   my $incrbkups = "$tmpMisc/incrbackups.txt";
   my @bkpArray;
   my @copybkpArr;

   open FILE, $incrbkups;
   @bkpArray = <FILE>;
   close FILE;   
   
   foreach my $x(@bkpArray)
   {
      if ($x =~ m/.*\/(.*)/)
      {
         push (@copybkpArr, $1);
      }
   }

   @copybkpArr = join(',', @copybkpArr);

   appendXttPlan (\%tsHash);

   my @tbsArray = readFileNormal($tsbkupmap,1);
   my %fileArrayHash = ();
   my $fileArrayHashP = \%fileArrayHash;

   foreach my $x (@tbsArray)
   {
      $x = trim ($x);
      debug "XXX: $x\n";
      if ($x =~ m/.*?::(.*?):::.*=(.*)/)
      {
         my $fileStr = $1;
         my $bkpName = $2;
         my @lfArray = split /,/, $fileStr;
         foreach my $y (@lfArray)
         {
            if (checkEleExists(\@fileArray, $y))
            {
               debug "Exists $y\n";
               #next;
            }
            debug "XXX: Adding to $y\n";
            $fileArrayHashP->{"$y"}->{"bkpname"} = $bkpName;
         }
      }
   }

   genResFileAdded($fileArrayHashP);
   copyResFile();
   LogMessage ("checkAddDFilesBackup12C: End");
}

###############################################################################
# Function : checkAddDFilesPrepare
# Purpose  : See if any news files were added when using prepare method.
#            The logic is as follows. Find all the list of datafiles for the 
#            given set of tablespaces. See if they are already part of 
#            xttnewdatafiles.txt
###############################################################################
sub checkAddDFilesPrepare
{
   my @sqlOutput ;
   my @xttOut = ();
   my $tsName = '';
   my %dfHash;
   my %tsHash;
   my $dfHashP = \%dfHash;
   my $tsHashP = \%tsHash;
   my $xttnew = "$tmpMisc/xttnewdatafiles.txt.added";
   my $xttorg = "$tmp/xttnewdatafiles.txt";
   my $sqlfile = "$tmpMisc/diff.sql";
   my $tsbkmap = "$tmp/tsbkupmap.txt";
   my $incrbkups = "$tmpMisc/incrbackups.txt";

   my ($xttOutR, $sqlOutputR) = getXTTNewOld();

   @xttOut = @$xttOutR;
   @sqlOutput = @$sqlOutputR;

   foreach my $x(@xttOut)
   {
      chomp($x);
      if ($x =~ /^::(.*)$/)
      {
         $tsName = $1;
         $tsHashP->{"$tsName"}->{"tsname"} = $tsName;
         $tsHashP->{"$tsName"}->{"scn"} = 0;
      }
      elsif ($x =~ /(.*),(.*)$/)
      {
         my $fno = $1;
         my $fname = $2;
         $dfHashP->{"$1"}->{"tsname"} = $tsName;
         if ($fname =~ m/.*\/(.*).dbf/)
         {
            $dfHashP->{"$fno"}->{"fname"} = 
               $props{'stageondest'}."/$1.tf";
            print "Added fname here 1:".$dfHashP->{"$fno"}->{"fname"}."\n";
         }
      }
   }

   my @printFArray = ();
   my @tsArray = ();
   my $scn = 0;

   foreach my $x(@sqlOutput)
   {
      chomp($x);
      if ($x =~ /^::(.*):::SCN:::(.*)$/)
      {
         debug "YYY: $x\n";
         $scn = $2;
         $tsName = $1;
         my @fstArray = ();
         if (defined($tsHashP->{"$tsName"}->{"tsname"}))
         {
            delete $tsHashP->{"$tsName"};
         }
         else
         {
            $tsHashP->{"$tsName"}->{"scn"} = $scn;
            $tsHashP->{"$tsName"}->{"tsname"} = $tsName;
            $tsHashP->{"$tsName"}->{"files"} = [@fstArray];
            debug "YYY: adding $scn, $tsName";
         }
      }
      elsif ($x =~ /(.*)=.*?,.*?,(.*)$/)
      {
         #print "df".$1." name:". $2."\n";
         if (defined($dfHashP->{"$1"}->{"tsname"}))
         {
            delete $dfHashP->{"$1"};
         }
         else
         {
            my $fno = $1;
            my $fname = $2;
            $dfHashP->{"$fno"}->{"found"} = 0;
            $dfHashP->{"$fno"}->{"tsname"} = $tsName;
            debug "no found match $fname, $x\n";
            $fname = fixSlashName($fname);		
            if ($fname =~ m/.*\/(.*).dbf/)
            {
               debug "no found match1 $fname, $x\n";
               my $printFStr = "$1.tf";
               $dfHashP->{"$fno"}->{"fname"} = 
                  $props{'stageondest'}."/".$printFStr;
               print "Added fname here 2:".$dfHashP->{"$fno"}->{"fname"}." , fname is $fname\n";
               push (@printFArray, $printFStr);
               my @fstArray = ();
               if (defined($tsHashP->{"$tsName"}))
               {
                  if (@{$tsHashP->{"$tsName"}->{"files"}})
                  {
                     @fstArray = @{$tsHashP->{"$tsName"}->{"files"}};
                  }
                  push(@fstArray, $fno);
                  $tsHashP->{"$tsName"}->{"files"} = [@fstArray];
               }   
            }
         }
      }
   }
   @printFArray = join(',', @printFArray);

   my @fileArray = keys %dfHash;
   my $fcount = scalar @fileArray;
   if ($fcount == 0)
   {
      LogMessageScreen("No new datafiles added");
      return;
   }
   LogMessageScreen("$fcount new datafiles added");
   @fileArray = join(',', @fileArray);

   my $platName = getCurrPlatName();

   my $convCmd = "convert from platform \'$platName\' datafile ";
   foreach my $key (keys %dfHash)
   {
      $convCmd = $convCmd."'".$dfHashP->{"$key"}->{"fname"}."'".",";
      print $dfHashP->{"$key"}->{"tsname"}.",".
            $dfHashP->{"$key"}->{"fname"}."\n";
   }
   $convCmd =~ s/,$//;
   $convCmd = $convCmd." format '".$props{'storageondest'}.
              "/%N_%f.dbf' parallelism ".
              $props{'parallel'}.";";
   #print $convCmd."\n";
   
   my $prepCmd = "backup as copy tag 'prepare' datafile ".
                 "@fileArray format '".
                 $props{'dfcopydir'}."/%N_%f.tf';";
   #print $prepCmd."\n";
   
   my $newprepFile = "$tmpMisc/prepare".$tstamp.".cmd";
   open FILE, ">$newprepFile";
   print FILE $prepCmd."\n";
   close FILE;

   my $newConvFile = "$tmpMisc/single_rmanconv.cmd";
   open FILE, ">$newConvFile";
   print FILE $convCmd."\n";
   close FILE;
   
   my $fixNewDf = "$tmp/fixnewdf.txt";
   open FILE, ">$fixNewDf";
   print FILE "STARTXTTNEW\n";
   foreach my $x(@sqlOutput)   
   {
      chomp($x);
      print FILE "$x\n";
   }
   print FILE "ENDTXTTNEW\n";
   print FILE "STARTCONV::".PREPARE."\n";
   print FILE $convCmd."\n";
   print FILE "ENDCONV\n";
   close FILE;

   LogMessageScreen("Running prepare cmd for new filesx @printFArray");

   my $output = `rman target $rman_src_connstr cmdfile $newprepFile`;
   
   debug $output."\n";

   if ($output =~ /ERROR MESSAGE/)
   {
      Die("$output $!");
   }
   
   checkCopy($xttnew, $xttorg);

   foreach my $x (keys %tsHash)
   {
      debug "YYY: $x\n";
   }
   appendXttPlan (\%tsHash);

   my @tbsArray = readFileNormal($xttnew,1);
   my %fileArrayHash = ();
   my $fileArrayHashP = \%fileArrayHash;
   foreach my $x (@tbsArray)
   {
      $x = trim ($x);
      debug "XXX: $x\n";
      #0:::7,2,,0,1442645,0,0,0,TBS_2,TBS_2_7.dbf
      if ($x =~ m/(.*?),(.*)/)
      {
         my $fno = $1;
         my $bkpName = $2;
         if ($bkpName =~ m/.*\/(.*)\..*/)
         {
            $bkpName = $1;
         }
         if (!defined $fileArrayHashP->{"$fno"})
         {
            $fileArrayHashP->{"$fno"}->{"bkpname"} = $bkpName;
         }
      }
   }

   genResFileAdded($fileArrayHashP);
   copyResFile();
}

###############################################################################
# Function : getTBScn
# Purpose  : To get minimum CHECKPOINT_CHANGE# for datafiles belonging to a
#            given tablespace
###############################################################################
sub getTBScn
{
   my $sqlOutput ;
   my $tsName = $_[0];
   my $sqlQuery =
      'select min(d.checkpoint_change#) from v\$datafile d, v\$tablespace t'.
      ' where d.ts# = t.ts# and '.
      '       t.name = \''.$tsName.'\';';

   $sqlOutput = `sqlplus -s -L $sql_src_connstr <<EOF
                         $sqlSettings
                         $sqlQuery
                         quit;
EOF
`;

   chomp ($sqlOutput);
   $sqlOutput = trim ($sqlOutput);

   if ($sqlOutput =~ m/.*ORA-.*/)
   {
      LogMessage($sqlOutput);
      Die ("Unable to fetch min CHECKPOINT_CHANGE#");
   }

   return $sqlOutput;
}

###############################################################################
# Function : checkAddDFilesGetFile
# Purpose  : See if any news files were added when using getfile method.
#            The logic is as follows. Find all the list of datafiles for the 
#            given set of tablespaces. See if they are already part of 
#            xttnewdatafiles.txt
###############################################################################
sub checkAddDFilesGetFile
{
   my @sqlOutput ;
   my $xttnew = "$tmp/xttnewdatafiles.txt.added";
   my $xttorg = "$tmp/xttnewdatafiles.txt";
   my @xttOut = ();
   my $sqlfile = "$tmpMisc/diff.sql";
   my %dfHash;
   my %tsHash;
   my $dfHashP = \%dfHash;
   my $tsHashP = \%tsHash;

   if (!-e $xttorg)
   {
      LogMessageScreen("$xttorg not present, so can't check if new files got".
                         " added");
      return;
   }
   else
   {
      checkCopy($xttorg);
   }
   
   open FILE, "$xttorg";
   @xttOut = <FILE>;
   close FILE;
   
   &fetchCheckDirObjectsSRC($props{'srcdir'}, "", \%dirHash);

   foreach my $keys (keys %dirHash)
   {
      debug4 "prepare: Key is $keys\n";
      debug4 "prepare: Value is ".$dirHash{"$keys"}."\n";
   }
   &generate_batch_tsoutput(FIXNEWDFGET);

   open FILE, "$xttnew";
   @sqlOutput = <FILE>;
   close FILE;

   my $tsName = '';
   foreach my $x(@xttOut)
   {
      chomp($x);
      if ($x =~ /^::(.*)$/)
      {
         $tsName = $1;
         $tsHashP->{"$tsName"}->{"tsname"} = $tsName;
         $tsHashP->{"$tsName"}->{"scn"} = 0;
      }
      elsif ($x =~ /(.*),(.*)$/)
      {
         #print "df".$1." name:". $2."\n";
         $dfHashP->{"$1"}->{"found"} = 0;
         $dfHashP->{"$1"}->{"tsname"} = $tsName;
         my $fno = $1;
         my $fname = $2;
         if ($fname =~ m/.*\/(.*).(.*)/)
         {
            $dfHashP->{"$fno"}->{"fname"} = 
            $props{'stageondest'}."/$1.$3";
         }
      }
   }
   
   my @printFArray = ();
   my @tsArray = ();
   my $scn = 0;

   foreach my $x(@sqlOutput)
   {
      chomp($x);
      debug5 "checkAddDFilesGetFile: $x\n";
      if ($x =~ /^::(.*):::SCN:::(.*)$/)
      {
         $scn = $2;
         $tsName = $1;
         my @fstArray = ();
         if (defined($tsHashP->{"$tsName"}->{"tsname"}))
         {
            delete $tsHashP->{"$tsName"};
         }
         else
         {
            $tsHashP->{"$tsName"}->{"scn"} = $scn;
            $tsHashP->{"$tsName"}->{"tsname"} = $tsName;
            $tsHashP->{"$tsName"}->{"files"} = [@fstArray];
         }
      }
      elsif ($x =~ /^::(.*)$/)
      {
         $tsName = $1;
         my @fstArray = ();
         if (defined($tsHashP->{"$tsName"}->{"tsname"}))
         {
            delete $tsHashP->{"$tsName"};
         }
         else
         {
            $tsHashP->{"$tsName"}->{"scn"} = getTBScn($tsName);
            $tsHashP->{"$tsName"}->{"tsname"} = $tsName;
            $tsHashP->{"$tsName"}->{"files"} = [@fstArray];
         }
      }
      elsif ($x =~ /(.*),(.*)$/)
      {
         my $fno = $1;
         my $fname = $2;
         if (defined($dfHashP->{"$fno"}->{"tsname"}))
         {
            delete $dfHashP->{"$fno"};
         }
         else
         {
            $dfHashP->{"$fno"}->{"tsname"} = $tsName;
            if ($fname =~ m/.*\/(.*).(.*)/)
            {
               my $printFStr = "$1.(.*)";
               $dfHashP->{"$fno"}->{"fname"} = 
                  $props{'stageondest'}."/".$printFStr;
               push (@printFArray, $printFStr);
               my @fstArray = ();
               if (defined($tsHashP->{"$tsName"}))
               {
                  if (@{$tsHashP->{"$tsName"}->{"files"}})
                  {
                     @fstArray = @{$tsHashP->{"$tsName"}->{"files"}};
                  }
                  push(@fstArray, $fno);
                  $tsHashP->{"$tsName"}->{"files"} = [@fstArray];
               }   
            }
         }
      }
   }
   @printFArray = join(',', @printFArray);

   my @fileArray = keys %dfHash;
   my $fcount = scalar @fileArray;
   if ($fcount == 0)
   {
      LogMessageScreen("No new datafiles added");
      return;
   }
   @fileArray = join(',', @fileArray);
   LogMessageScreen("@fileArray $fcount new datafiles added");

   my $getfilex = $getfile.".added";
   my @getFileAr = ();
   open FILE, "$getfilex";
   @getFileAr = <FILE>;
   close FILE;

   my @getFileArOrig = ();
   open FILE, "$getfile";
   @getFileArOrig = <FILE>;
   close FILE;

   my $fixNewDf = "$tmp/fixnewdf.txt";
   open FILE, ">$fixNewDf";
   print FILE "STARTXTTNEW\n";
   foreach my $x(@sqlOutput)   
   {
      chomp($x);
      print FILE "$x\n";
   }
   print FILE "ENDTXTTNEW\n";
   print FILE "STARTCONV::".GETFILE."\n";

   my %diffHash;
   @diffHash{@getFileArOrig} = @getFileArOrig;
   my @output = grep {!exists $diffHash{$_}} @getFileAr;
   
   foreach my $x(@output)
   {
      chomp($x);
      print FILE "$x\n";
   }
   print FILE "ENDCONV\n";
   close FILE;

   LogMessageScreen("Running prepare cmd for new files @printFArray");

   checkCopy($xttnew, $xttorg);

   appendXttPlan (\%tsHash);

   Die(
   "The incremental backup was not taken as a datafile has been added ".
   "to the tablespace:\n".
   "\n".
   " Please Do the following:\n".
   "--------------------------\n".
   " 1. Copy fixnewdf.txt from source to destination temp dir\n\n".
   " 2. On Destination, run \$ORACLE_HOME/perl/bin/perl xttdriver.pl --fixnewdf\n\n".
   " 3. Re-execute the incremental backup in source:\n".
   "    \$ORACLE_HOME/perl/bin/perl xttdriver.pl -i\n\n".
   " \n".
   "    NOTE:  Before running incremental backup, delete FAILED in source temp dir or \n".
   "           run xttdriver.pl with -L option"
   );
}

###############################################################################
# Function : getxttnewdf
# Purpose  : Generate new xtt datafiles
###############################################################################
sub getxttnewdf
{
   my @sqlOutput ;
   my $xttorg = "$tmp/xttnewdatafiles.txt";
   my $xttorgE = "$tmpMisc/xttnewdatafiles.txt.all";
   my @xttOut = ();
   my $sqlfile = "$tmpMisc/diff.sql";

   splitTBSString($props{'tablespaces'});

   open FILE, ">$sqlfile";
   print FILE << "EOF";
SET TRIMSPOOL ON TAB OFF PAGES 0 EMB OFF LINES 32767 FEEDBACK OFF SERVEROUTPUT ON FORMAT TRUNCATE COLSEP "" RECSEP OFF DEFINE "&" VERIFY OFF
SELECT CASE
         WHEN rn = 1
         THEN '::' || ts_name || CHR(10)
       END
    || file#
    || ','
    || df_name
  FROM (
SELECT ROW_NUMBER() OVER (PARTITION BY t.name ORDER BY d.file#) rn
     , t.ts#
     , t.name ts_name
     , d.file#
     , '&1' || '/' || t.name || '_' || d.file# || '.dbf' df_name
  FROM v\$tablespace t
     , v\$datafile d
 WHERE t.ts# = d.ts#
   AND (
EOF
   my $x = 0;
   for ($x = 0 ; $x < $numTbArrays - 1; $x = $x + 1)
   {
   print FILE << "EOF";
       t.name IN (@{$tbsArrayRef[$x]}) OR 
EOF
   }
   print FILE << "EOF";
       t.name IN (@{$tbsArrayRef[$x]})
       )
       )
 ORDER BY
       ts#
     , file#
/
EXIT
EOF
   close FILE;
   my $cmdStr = "sqlplus -L -s $sql_src_connstr \@$sqlfile ".
                $props{'storageondest'};

   LogMessage("Find list of datafiles in system");

   print "$cmdStr\n";
                
   my $sqlOutputStr = `$cmdStr`;
   my @sqlOutput = split /\n/, $sqlOutputStr;
   my @xttNewFno;
   foreach my $x (@sqlOutput)
   {
      if ($x =~ m/(.*),.*/)
      {
         push (@xttNewFno, $1);
      }
   }

   my %diffHash;
   @diffHash{@filesBkArray} = @filesBkArray;
   my @output = grep {!exists $diffHash{$_}} @xttNewFno;

   open FILE, ">$xttorgE";
   foreach my $x(@sqlOutput)
   {
      chomp($x);
      print FILE $x."\n";
   }
   close FILE;

   open FILE, ">$xttorg";
   foreach my $x(@sqlOutput)
   {
      chomp($x);
      if ($x =~ m/(.*),.*/)
      {
         print FILE $x."\n";
      }
      else
      {
         print FILE $x."\n";
      }
   }
   close FILE;

   checkError ("Error in executing $sqlfile", $sqlOutputStr);

   LogMessage("Done finding list of datafiles in system");
}

sub addQuote                                                                    
{                                                                               
   my $str = $_[0];                                                             
   debug "$str\n";                                                              
   my @array1 = split /,/, $str;                                                
   my $str1 = join ",\n ", map "'$_'", @array1;
   debug "$str1\n";                                                             
   return $str1;                                                                
}        

sub backincr
{
   LogMessage ("Backup incremental");
   checkErrFile();
   ## Move out any existing xttplan.txt.new
   my $xttpathnew = "$tmp/xttplan.txt.new";
   my @trnsfrFiles = ();
   my $tsbkupmap = "$tmp/tsbkupmap.txt";
   my $incrbkups = "$tmpMisc/incrbackups.txt";

   # check if new files were added
   if (defined($props{'srclink'}) && 
       defined($props{'srcdir'}) && 
       defined($props{'dstdir'}))
   {
      checkAddDFilesGetFile();
   }
   elsif ($props{'usermantransport'})
   {
      checkAddDFilesBackup12C();
   }
   else
   {
      checkAddDFilesPrepare();
   }

   checkMove($xttpathnew);

   ## Generate the next round xttplan.txt
   &generate_batch_tsoutput(BCKPINCR);

   ## At this point, we must have a new xttplan.txt.new
   ## populated with required from_scn's  for next incremental backup.

   LogMessage ("Starting incremental backup") ;

   # Clean up any rmanincr.cmd from TMPDIR area.
   my $rmanincrpath = "$tmpMisc/rmanincr.cmd";
   checkMove($rmanincrpath);

   my $backupformat = $props{'backupformat'};
   ## Remove trailing '/'s
   $backupformat = $1 if($backupformat=~/(.*)\/$/);

   if ($context->{"bkpexport"} || $context->{"includeexport"})
   {
      open(XTTPLAN, $xttpath) || die 'Cant find xttplan.txt, TMPDIR undefined';

      my $rman_str1 = "set nocfau;";
      my $rman_str;
      my @scnArray = ();
      my @scnSortedArray = ();
      my $scn;
      my $rmCmd;

      while (<XTTPLAN>)
      {
         if (/(\S+)::::(\S+)/)
         {
            push (@scnArray, $2);
         }
      }
      close XTTPLAN;

      if (!@scnArray)
      {
         ErrorMessage ("BACKUPINCR: Could not find lowest SCN");
      }

      @scnSortedArray = sort (@scnArray);

      $scn = $scnSortedArray[0];

      my $quotedTbs = addQuote($props{'tablespaces'});

      $rmCmd = "BACKUP FOR TRANSPORT INCREMENTAL from scn $scn TABLESPACE ".
               $quotedTbs.
               " FORMAT '$backupformat/%U'".
               " DATAPUMP FORMAT '$backupformat/%U';";
      open(RMANINCR, ">$tmpMisc/rmanincr.cmd") || 
           Die("Cant open rmanincr.cmd $!");
      print RMANINCR "$rmCmd";
      close RMANINCR;
   }
   else
   {
      ## Generate $tmp/rmanincr.cmd
      open(RMANINCR, ">$tmpMisc/rmanincr.cmd") || Die("Cant open rmanincr.cmd $!");

      ## Parse out xttplan.txt and build the rman command
      open(XTTPLAN, $xttpath) || die 'Cant find xttplan.txt, TMPDIR undefined';

      my $rman_str1 = "set nocfau;";
      my $rman_str;

      while (<XTTPLAN>)
      {
         if (/(\S+)::::(\S+)/)
         {
            my $tablespace = $1;
            my $scn        = $2;
            my $rman_str;

            print RMANINCR $rman_str1 . "\n";

            $rman_str = "host 'echo ts::$tablespace';";
            print RMANINCR $rman_str . "\n";

            if ($context->{"bkpincr"})
            {
               $rman_str = "backup for transport allow INCONSISTENT ".
                           "incremental from scn $scn ";
            }
            else
            {
               $rman_str = "backup incremental from scn $scn ";
            }
            print RMANINCR $rman_str . "\n";

            if ($context->{"incremental"})
            {
               $rman_str = "  tag tts_incr_update tablespace '$tablespace' ".
                           " format";
               print RMANINCR $rman_str . "\n";
            }
            else
            {
               $rman_str = "  tablespace '$tablespace' format";
               print RMANINCR $rman_str . "\n";
            }

            $rman_str = " '$backupformat/%U';";
            print RMANINCR $rman_str . "\n";
         }
      }
      close(XTTPLAN);
      close(RMANINCR);
   }

   ## Execute the rman command here
   my $output = RunRmanCmd($rman_src_connstr, $rmanincrpath, "incrbackup");

   checkMove ($tsbkupmap);
   checkMove ($incrbkups);

   &gentablespace_backupmap( $output ) ;

   if ($metaTransfer)
   {
      @trnsfrFiles = ();
      push (@trnsfrFiles, "$tmp/tsbkupmap.txt");
      transferFiles (@trnsfrFiles);

      open FILE, "$tmpMisc/incrbackups.txt";
      @trnsfrFiles = <FILE>;
      close FILE;

      $context->{"desttmp"} = $props{'stageondest'};
      transferFiles (@trnsfrFiles);
      $context -> {"desttmp"} = $props{'desttmpdir'};
   }

   LogMessage ("Done backing up incrementals");
   copyImpfiles();
   genResFile();
   fixResFile();
   copyResFile();
   newplan();
   exit;
}

###
### Incremental Ends here
###
####################################
# Check if element exists in array.
####################################
sub checkInArray
{
   my $element = $_[0];

   if (@rolltbsArray)
   {
      if ($tbsHash{"$element"})
      {
         return 1;
      }
      else
      {
         return 0;
      }
   }
   else
   {
      return 1;
   }
}

###
### Rollforward Starts here - on destination
###
### New changes in v1.1
###
### xttrollforwarddest.sql is now a generated file.
###
### All file processing is handled by perl itself.
### xttrollforwarddest.sql will be called for each tablespace
### The destination database will be started up in nomount
### until all the tablespaces are rollforwarded.
###
sub rmconvertedincr
{
   # Check if any failure occured and stop exection
   checkErrFile();

   my $backupondest  = $props{'backupondest'};
   my $asmhome       = $props{'asm_home'};
   my $asmsid        = $props{'asm_sid'};
   my $rmcmd         = "";

   if (defined $props{'asm_home'})
   {
      ## Lets first delete the incremental backup if any
      ## this will happen through asmcmd
      my $oh_saved = $ENV{'ORACLE_HOME'};
      my $ohsid_saved = $ENV{'ORACLE_SID'};
      my $asmcmd = 0 ;
      my $asmcmd_str;

      $ENV{'ORACLE_HOME'} = $asmhome;
      $ENV{'ORACLE_SID'} = $asmsid;

      # Remove trailing spaces
      $backupondest =~ s/\s+$//;
      $asmsid =~ s/\s+$//;

      $asmcmd_str = "asmcmd rm $backupondest/$xtts_incr_backup";
      debug $asmcmd_str . "  $asmhome .. $asmsid \n" ;

      $asmcmd = `asmcmd rm $backupondest/$xtts_incr_backup`;
      debug "ASMCMD:  $asmcmd\n";

      $ENV{'ORACLE_HOME'} = $oh_saved;
      $ENV{'ORACLE_SID'} = $ohsid_saved;
      if ($asmcmd == 0)
      {
         Unlink ("$backupondest/$xtts_incr_backup", 1);
      }
   }
   else
   {
      Unlink ("$backupondest/$xtts_incr_backup", 1);
   }

}

###############################################################################
# Function : ChecktoProceed
# Purpose  : When running the roll forward in parallel, we will check if we can
#            fork any more jobs
###############################################################################
sub ChecktoProceed
{
   my $parallel = $_[0];
   # Check if any failure occured and stop exection
   checkErrFile();
   my $running = 0;

   if ($#forkArray <= 0)
   {
      return;
   }
   do
   {
      $running = 0;
      foreach my $index (0 .. $#forkArray)
      {
         my $x = $forkArray[$index];
         if ($x <= 0)
         {
            next;
         }
         my $kid = waitpid($x, WNOHANG);
         if ($kid >= 0)
         {
            $running = $running + 1;
         }
         else
         {
            $forkArray[$index] = 0;
         }
      }
   } while ($running >= $parallel);

   return;
}

sub UpdateForkArray
{
   my ($pid, $parallel) = @_;

   if ($#forkArray < $parallel)
   {
      push (@forkArray, $pid);
   }
   else
   {
      foreach my $index (0 .. $#forkArray)
      {
         my $x = $forkArray[$index];
         if ($x == 0)
         {
            $forkArray[$index] = $pid;
            last;
         }
      }
   }
}

###############################################################################
# Function : FixCnvScripts
# Purpose  : Fix the scripts that has details about incremental backup
###############################################################################
sub FixCnvScripts
{
   my $toFixSql  = $_[0];
   my $inpSql    = $_[1];
   my $fixedStr  = $_[2];
   my $fixedStrL = "";
   my $len = 0;

   open XTTS_INCR_BACKUP, "<$inpSql";
   open XTTS_INCR_BACKUP1, ">$toFixSql";
   my @arrayXttincr = <XTTS_INCR_BACKUP>;

   # Bug 20192155: Use xib instead of "xtts_incr_backup" to prevent
   # ORA error ORA-15126 with ASM
   $fixedStrL = substr($fixedStr, 0, 42);
   $xtts_incr_backup = "xib"."_".$fixedStrL;
   $len = length ($xtts_incr_backup);
   if ($len > 50)
   {
      ErrorMessage ("Length of backupiece exceeds 50 chars $xtts_incr_backup");
   }

   foreach my $x (@arrayXttincr)
   {
      chomp($x);
      if ($x =~ m/(.*)xtts_incr_backup(.*)\,/)
      {
         print XTTS_INCR_BACKUP1 "$1$xtts_incr_backup$2,\n";
      }
      elsif ($x =~ m/(.*)xtts_incr_backup(.*)/)
      {
         print XTTS_INCR_BACKUP1 "$1$xtts_incr_backup$2\n";
      }
      elsif (!(($platformid == 0) && ($x =~ m/(.*)pltfrmfr(.*)/)))
      {
         print XTTS_INCR_BACKUP1 "$x\n";
      }
      else
      {
         print XTTS_INCR_BACKUP1 "$x\n";
      }
   }
   close XTTS_INCR_BACKUP1;
   close XTTS_INCR_BACKUP;
}

###############################################################################
# Function : sortArrayOrder
# Purpose  : Sort the Array based on piece
###############################################################################
sub sortArrayOrder
{
  return sort {
               (($a =~ /::(.*):::.*/)[0] <=> ($b =~ /::(.*):::.*/)[0] ||
                ($a =~ /:::(.*?)=/)[0] <=> ($b =~ /:::(.*?)=/)[0]
               )
               } @_;
}

###############################################################################
# UTIL functions
# Following functions are useful for conversion, rollforward etc
###############################################################################
sub ReadFile
{
   my $fileRead = $_[0];
   my $output;
   my @outputArray;

   open FILEX, $fileRead or Die ($!);
   @outputArray = <FILEX>;
   $output .= $_ foreach @outputArray;
   close FILEX;

   return $output;
}

sub RunRmanCmd
{
   my ($connstr, $cmdfile, $cmdStr, $noExit) = @_;
   my ($rmanTrace, $traceFile, $logFile) = GetRMANTrace($cmdStr);
   my $rmanCmd;
   my $output;

   if ($rmanLog)
   {
      $rmanCmd = "rman target $connstr $rmanTrace cmdfile $cmdfile";
      Mylog("RunRmanCmd: $logFile\n $rmanCmd");
      system ("$rmanCmd > /dev/null 2>&1") == 0 or Die ($!);
      $output = ReadFile($logFile);
   }
   else
   {
      $output = `rman target $connstr $rmanTrace cmdfile $cmdfile`;
   }
   debug("$cmdfile");
   debug ($output);

   if ($output =~ /ERROR MESSAGE/ && !$noExit)
   {
      Die("$output $!");
   }

   Unlink ($traceFile);
   Unlink ($logFile);

   return $output;
}

sub ConvertBackup
{
   my $backup   = $_[0];
   my $dfno     = $_[1];
   my $fixCnvSql;
   my $outputCnvrt;

   $fixCnvSql  = "$tmpMisc/xxttconv_$backup"."_$dfno.sql";

   FixCnvScripts ($fixCnvSql, $cnvrSql, $backup."_".$dfno);
   Unlink ("$backupondest/$xtts_incr_backup", 1);

   my $outputCnvrt =
      `sqlplus -L -s \"$connectstringcnvinst\" \@$fixCnvSql $stageondest/$backup $backupondest $platformid`;
   debug "sqlplus -L -s \"$connectstringcnvinst\" \@$fixCnvSql $stageondest/$backup $backupondest $platformid\n";   
   checkError ("$fixCnvSql execution failed", $outputCnvrt);
   Unlink ($fixCnvSql);
}

sub RollPiece
{
   my $sqlfile = $_[0];
   my $outputCnvrt;

   ## now call generated rollforward
   $outputCnvrt =
      `sqlplus -L -s \"/ as sysdba\" \@$sqlfile`;
   checkError ("$sqlfile execution failed", $outputCnvrt);
}

sub ConvertRoll
{
   my ($fixedStr, $oldre, $rb, $rend, $bkupList, $rmList) = @_;
   my $rollFile;

   $rollFile = "$tmpMisc/xxttroll_$fixedStr.sql";

   open (XTTROLL, ">$rollFile") or Die $!;
   print XTTROLL $rb;

   foreach my $y (@{$rmList})
   {
      print XTTROLL $y;
   }

   foreach my $backup (@{$bkupList})
   {
      my $re = $oldre;
      ConvertBackup ($backup, $fixedStr);
      $re =~ s/##xtts_incr_backup/$xtts_incr_backup/;
      print XTTROLL $re;
   }
   print XTTROLL $rend;
   close XTTROLL;

   RollPiece ($rollFile);

   rmconvertedincr();
}

sub RestoreRecover
{
   my ($fixedStr, $finalRes) = @_;
   my $fixedStrL = substr($fixedStr, 0, 25);
   my $cmdfile = "$tmpMisc/xttresrec_$fixedStrL.cmd";

   open RMANRE, ">$cmdfile";
   print RMANRE "$finalRes\n";
   close RMANRE;

   my ($rmanTrace, $traceFile) = GetRMANTrace("resrec");
   my $output = `rman target $rman_dest_connstr $rmanTrace cmdfile $cmdfile`;
   debug ($output);

   if ($output =~ /ERROR MESSAGE/)
   {
      Die("$output $!");
   }

   Unlink ($traceFile);
}


###############################################################################
# End of UTIL functions
# Following functions are useful for conversion, rollforward etc
###############################################################################

###############################################################################
# Function : clearUpRollfwd
# Purpose  : Clear the scripts and converted incrementals after rollfwd
###############################################################################
sub clearUpRollfwd
{
   Unlink ($fixCnvSql);
   Unlink ($xttrollforwardp);
   Unlink ($fixRollSql);
   rmconvertedincr();
}

sub rollforward
{
   LogMessage ("Start rollforward");

   # Check if any failure occured and stop exection
   checkErrFile();

   my $connectstringdest = "/ as sysdba";
   my $ohcnv = $props{'cnvinst_home'};
   my $ohcnvsid = $props{'cnvinst_sid'};
   my $tsbkupmappath = "$tmp/tsbkupmap.txt";
   my $tsbkupmappathC = "$tmp/tsbkupmap_comp.txt";
   my $tsn;
   my $fixedSql;
   my $pid = 0;
   my $i = 0;
   my $parent = 0;
   my $count = 0;
   my $newrm;
   my $oldre;

my $rb = q(

   set serveroutput on;

   DECLARE
   outhandle varchar2(512) ;

   outtag varchar2(30) ;
   done boolean ;
   failover boolean ;
   devtype VARCHAR2(512);

   BEGIN

   DBMS_OUTPUT.put_line('Entering RollForward');

   -- Now the rolling forward.
   devtype := sys.dbms_backup_restore.deviceAllocate;

   sys.dbms_backup_restore.applySetDatafile(
   check_logical => FALSE, cleanup => FALSE) ;

   DBMS_OUTPUT.put_line('After applySetDataFile');

   );

my $rm = q(

   sys.dbms_backup_restore.applyDatafileTo(
     dfnumber => ##fno,
     toname => ##fname,
     fuzziness_hint => 0, max_corrupt => 0, islevel0 => 0,
     recid => 0, stamp => 0);

   );

my $rmend = q(
  DBMS_OUTPUT.put_line('Done: applyDataFileTo');
  );

my $re = q(
  DBMS_OUTPUT.put_line('Done: applyDataFileTo');

  -- Restore Set Piece
  sys.dbms_backup_restore.restoreSetPiece(
    handle => '##backupondest/##xtts_incr_backup',
    tag => null, fromdisk => true, recid => 0, stamp => 0) ;

  DBMS_OUTPUT.put_line('Done: RestoreSetPiece');

  -- Restore Backup Piece
  sys.dbms_backup_restore.restoreBackupPiece(
    done => done, params => null, outhandle => outhandle,
    outtag => outtag, failover => failover);

  DBMS_OUTPUT.put_line('Done: RestoreBackupPiece');

  );

my $rend = q(
  sys.dbms_backup_restore.restoreCancel(TRUE);
  sys.dbms_backup_restore.deviceDeallocate;

  END;
  /
  exit

  );

   $re =~ s/##backupondest/$backupondest/;
   $oldre = $re;

   if (!defined($ohcnv))
   {
      $connectstringcnvinst = "/ as sysdba";
   }
   else
   {
      debug "convert instance: $ohcnv \n";
      debug "convert instance: $ohcnvsid \n";

      $connectstringcnvinst =
        "/\@(DESCRIPTION=(ADDRESS=(PROTOCOL=BEQ)(PROGRAM=$ohcnv/bin/oracle)".
        "(ARGV0=oracle$ohcnvsid)(ARGS='(DESCRIPTION=(LOCAL=YES)".
        "(ADDRESS=(PROTOCOL=BEQ)))')".
        "(ENVS='ORACLE_HOME=$ohcnv,ORACLE_SID=$ohcnvsid'))".
        "(CONNECT_DATA=(SID=$ohcnvsid))) as sysdba";
   }

   my %tsbkupmap;
   my @tsArray = ();
   my @tsArrayC = ();

   open my $in, $tsbkupmappath or Die ("$tsbkupmappath $!");
   @tsArray = <$in>;
   close $in;

   open my $in, $tsbkupmappathC;
   @tsArrayC = <$in>;
   close $in;

   foreach my $x (sortArrayOrder @tsArray)
   {
      $_ = $x;
      next if /^#/;
      chomp($x);
      if (CheckEleExists (\@tsArrayC,$x))
      {
         next;
      }
      if (m/(\S+):::.*?=(\S+)/g)
      {
         push (@{$tsbkupmap{$1}->{"arr"}}, $2);
         $tsbkupmap{$1}->{"tstr"} = $x;
      }
   }

   ##
   ## Putting database on target in nomount
   ## as it could cause the following error.
   ## ORA-00600: internal error code, arguments: [2130], [33], [32], [4]
   ## The reason for this is :
   ##
   ## The code is trying to access KCCDEDBF (datafile) record# 33 when there
   ## is only record# 32.  It looks when you try to apply the incremental
   ## backup on linux box, you are expecting the datafile# 33 to exists in the
   ## target database. However, that can't be always true.
   ##
   ## This is worked around by starting the target database iin nomount.
   ## The convert call/script should work in nomount state of database too.
   ##
   if (defined($context->{"rolltbs"}))
   {
      checkDBState();
   }

   debug3 ("ROLLFORWARD: Starting DB in nomount mode");

   my $outputstart =  `sqlplus -L -s \"/ as sysdba\" \@xttstartupnomount.sql`;
   checkError ("Error in executing xttstartupnomount.sql", $outputstart);

   ## Generate xttrollforwarddest.sql that is the script
   ## that will rollforward all the converted datafiles.
   my $tsbkcount = scalar keys %tsbkupmap;

   if ($tsbkcount == 0)
   {
      Die ("No tablepsace entries found");
   }

   my @sortedkeys = sort keys %tsbkupmap;

   foreach $tsn (@sortedkeys)
   {
      my ($ts, $rdfno, $order) = split(/::/, $tsn);
      my $fixedStr;

      if ($context->{"rolltbs"})
      {
         my $checkArray = checkInArray($ts);
         if ($checkArray == 0)
         {
            next;
         }
      }

      debug "rdfno " . $rdfno . "\n";
      my @rdfnos = split /,/,  $rdfno;

      open (ROLLPLAN, "$tmp/dfcopy.txt") or Die $!;

      my $scrape = 0;

      # Check if any failure occured and stop exection
      checkErrFile();

      debug "BEFORE ROLLPLAN\n";

      my @rmList = ();

      while (<ROLLPLAN>)
      {
         chop;
         my $oldrm = $rm;

         my  $dfstr = $_;
         my ($dfno, $dfname) = split /:::/, $dfstr;
         my $ind;

         ## include the dfno only if present in the tsbkupmap.txt list
         ## of dfnos.
         my $found = 0;

         for ($ind = 0; $ind <= $#rdfnos ; $ind++)
         {
            if ($dfno == $rdfnos[$ind])
            {
               $found = 1;
               last;
            }
         }

         if ($found == 1)
         {
            debug "datafile number : $dfno  \n";
            debug "datafile name   : $dfname\n";

            $newrm = $rm;
            $newrm =~ s/##fno/$dfno/;
            $newrm =~ s/##fname/'$dfname'/;
            push (@rmList, $newrm);
         }
      }

      push (@rmList, $rmend);
      close(ROLLPLAN);
      debug "AFTER ROLLPLAN\n";

      $rollParallel = $props{'rollparallel'};

      $fixedStr = $rdfno;
      $fixedStr =~ tr/,/_/;

      # Bug 20192155: Use xib instead of "xtts_incr_backup" to prevent
      # ORA error ORA-15126 with ASM
      my $fixedStrL = substr($fixedStr, 0, 25);

      if ($rollParallel)
      {
         ChecktoProceed($rollParallel);

         $pid = fork();

         if ($pid == 0)
         {
            ConvertRoll ($fixedStrL, $oldre, $rb ,$rend, 
                        \@{$tsbkupmap{$tsn}->{"arr"}}, \@rmList);
            #Add the list of backup pieces already completed
            AddTsBkp($tsbkupmap{$tsn}->{"tstr"});
            exit (0);
         }
         else
         {
            UpdateForkArray ($pid, $rollParallel);
         }
      }
      else
      {
         ConvertRoll ($fixedStrL, $oldre, $rb ,$rend, 
                      \@{$tsbkupmap{$tsn}->{"arr"}}, \@rmList);
         #Add the list of backup pieces already completed
         AddTsBkp($tsbkupmap{$tsn}->{"tstr"});
      }
   }

   while((my $pid = wait()) > 0)
   {
      #sleep (1);
   }

   # Check if any failure occured and stop exection
   checkErrFile();

   my $outputstart =  `sqlplus -L -s \"/ as sysdba\" \@xttdbopen.sql`;

   LogMessage ("End of rollforward phase");
   copyImpfiles();
   return;
}

sub findCompRes
{
   my $handle = $_[0];
   my @compArray = readFileNormal($resFile, 1);
   my @finArray = ();

   foreach my $x (@compArray)
   {
      my $y = trim($x);
      if ($y =~ m/$handle/)
      {
         push(@finArray, $x);
      }
   }

   return @finArray;

}

###############################################################################
# Function : AddTsBkp
# Purpose  : Add backup pieces already completed
###############################################################################
sub AddTsBkp
{
   my $str = $_[0];
   my @dfCompArray = ();
   my $dfNo = 0;
   my $fName = '';
   my @output = ();

   if ($str =~ m/.*=(.*)/)
   {
      @dfCompArray = findCompRes($1);
   }

   foreach my $x (@dfCompArray)
   {
      $x = trim ($x);
      if ($x =~ m/.*:::(.*?),.*?,(.*?),.*/)
      {
         $dfNo = $1;
         $fName = $2;
         updateRestoreDFCopy($x, $dfNo, $fName, 0, \@output, $str);
         $str = 0;
      }
   }
}

sub uniq 
{
    my %seen;
    grep !$seen{$_}++, @_;
}

###############################################################################
# Function : resrecBkp
# Purpose  : Restore recover backup piece
###############################################################################
sub resrecBkp
{
   my $option = $_[0];

   LogMessage ("Start restore/recover");

   # Check if any failure occured and stop exection
   checkErrFile();

   my $tsbkupmappath  = "$tmp/tsbkupmap.txt";
   my $tsbkupmappathC = "$tmp/tsbkupmap_comp.txt";
   my $tsn;
   my $fixedSql;
   my $pid = 0;
   my $i = 0;
   my $parent = 0;
   my $count = 0;
   my $newrm;
   my $oldre;
   my $platName = $context->{"platname"};

   my %tsbkupmap;
   my @tsArray = ();
   my @tsArrayC = ();
   
   open my $in, $tsbkupmappath or Die ("$tsbkupmappath $!");
   @tsArray = <$in>;
   close $in;

   open my $in, $tsbkupmappathC;
   @tsArrayC = <$in>;
   close $in;

   foreach my $x (sortArrayOrder @tsArray)
   {
      $x = trim($x);
      if ((!defined($context->{"resincrdmp"}) && !defined($context->{"includeimport"})) &&
          CheckEleExists (\@tsArrayC,$x))
      {
         next;
      }
      if ($x =~ m/(\S+):::.*?=(\S+)/g)
      {
         push (@{$tsbkupmap{$1}->{"arr"}}, $2);
         $tsbkupmap{$1}->{"tstr"} = $x;
      }
   }

   my $tsbkcount = scalar keys %tsbkupmap;

   if ($tsbkcount == 0)
   {
      Die ("No tablepsace entries found");
   }

   my @sortedkeys = sort keys %tsbkupmap;
   my $res = '';
   my $finalRes = '';

   foreach $tsn (@sortedkeys)
   {
      my ($ts, $rdfno, $order) = split(/::/, $tsn);
      my $fixedStr;

      debug "rdfno " . $rdfno . "\n";
      my @rdfnos = split /,/,  $rdfno;

      @rdfnos = uniq(@rdfnos);

      open (ROLLPLAN, "$tmp/xttnewdatafiles.txt") or Die $!;

      my $scrape = 0;

      # Check if any failure occured and stop exection
      checkErrFile();

      debug "BEFORE ROLLPLAN\n";

      my @rmList = ();
      my $dfnofinal = 0;

      $res = '';
      while (<ROLLPLAN>)
      {
         if ($_ !~ /::/)
         {
            chop;

            my  $dfstr = $_;
            my ($dfno, $dfname) = split /,/, $dfstr;
            my $ind;

            ## include the dfno only if present in the tsbkupmap.txt list
            ## of dfnos.
            my $found = 0;

            for ($ind = 0; $ind <= $#rdfnos ; $ind++)
            {
               if ($dfno == $rdfnos[$ind])
               {
                  $found = 1;
                  debug "XXX: $dfname, $dfno, $option, $rdfnos[$ind], $#rdfnos\n";
                  if (($option == RESTORE) || ($option == RECOVER))
                  {
                     if ($res ne '')
                     {
                        $res = $res.",\n";
                     }
                     # Enh 25192728: Use "_" instead of ".", if bug 25183374
                     # gets fixed removed the lines upto # Enh end
                     if ($dfname =~ m/(.*)\.([0-9]+)\.([0-9]+)/)
                     {
                        my $olddfname = $dfname;
                        $dfname = "$1_$2_$3";
                        LogMessage ("Using $dfname instead of $olddfname");
                     }
                     # Enh 25192728 end
                     if ($option == RECOVER)
                     {
                        $res = $res."'$dfname'";
                        debug "XXX: res is $res\n";
                     }
                     else
                     {
                        $res = $res."$dfno format '$dfname'";
                        debug "XXX: res is $res\n";
                     }
                  }
               }
            }
         }
      }

      if ($option == RESTORE)
      {
         $finalRes =
            "restore from platform '$platName' FOREIGN DATAFILE ".
            $res.
            " from backupset '$stageondest/@{$tsbkupmap{$tsn}->{\"arr\"}}';\n";
      }
      elsif ($option == RECOVER)
      {
         $finalRes =
            " recover from platform '$platName' FOREIGN DATAFILECOPY ".
            $res.
            " from backupset '$stageondest/@{$tsbkupmap{$tsn}->{\"arr\"}}';\n";
      }

      close(ROLLPLAN);
      debug "AFTER ROLLPLAN\n";

      $rollParallel = $props{'rollparallel'};

      $fixedStr = $rdfno;
      $fixedStr =~ tr/,/_/;

      if ($rollParallel)
      {
         ChecktoProceed($rollParallel);

         $pid = fork();

         if ($pid == 0)
         {
            RestoreRecover ($fixedStr, $finalRes);
            # Add finished backup pieces
            AddTsBkp($tsbkupmap{$tsn}->{"tstr"});
            exit (0);
         }
         else
         {
            UpdateForkArray ($pid, $rollParallel);
         }
      }
      else
      {
         RestoreRecover ($fixedStr, $finalRes);
         # Add finished backup pieces
         AddTsBkp($tsbkupmap{$tsn}->{"tstr"});
      }
   }

   while((my $pid = wait()) > 0)
   {
      #sleep (1);
   }

   # Check if any failure occured and stop exection
   checkErrFile();

   LogMessage ("End of restore/recover phase");
}

sub createDumpFile
{
   my $option = $_[0];
   my $finalRes = '';
   my $bkPiece = '';
   my $platName = $context->{"platname"};

   LogMessage ("Start creating dumpfile");

   # Check if any failure occured and stop exection
   checkErrFile();

   my $tsbkupmappath = "$tmp/tsbkupmap.txt";
   my %tsbkupmap;
   my @tsArray = ();

   open my $in, $tsbkupmappath or Die ("$tsbkupmappath $!");
   @tsArray = <$in>;
   close $in;

   foreach my $x (sortArrayOrder @tsArray)
   {
      $_ = $x;
      next if /^#/;
      if (m/.*DMPEXP::(.*)/)
      {
         $bkPiece = $1;
         last;
      }
   }

   my $dmpFile = "impdp"."_".$tstamp.".dmp";
   my $dumpDir;

   $context->{"dmpfile"} = $dmpFile;

   if (defined($props{'dumpdir'}))
   {
      $dumpDir = $props{'dumpdir'};
      if (!-e $dumpDir)
      {
         $dumpDir = $tmp;
      }
   }
   else
   {
      $dumpDir = $tmp;
   }

   $finalRes =
      " restore from platform '$platName' ".
      " dump file '$dmpFile' ".
      " datapump destination '$dumpDir' ".
      " from backupset '$stageondest/$bkPiece';\n";

   debug "$finalRes\n";

   open RMANRE, ">rman_createdmp.cmd";
   print RMANRE "$finalRes\n";
   close RMANRE;
   my $output = RunRmanCmd($rman_dest_connstr, "rman_createdmp.cmd", 
                           "createdumpfile");

   # Check if any failure occured and stop exection
   checkErrFile();

   LogMessage ("End of creating dumpfile");
}

###
### Rollforward Ends here - on destination
###

###
### xttplan.txt with new fromscn -- STARTS
###
sub newplan()
{
   # Check if any failure occured and stop exection
   checkErrFile();

   ## Move the current xttplan.txt.new as xttplan.txt
   ## The xttplan.txt.new gets generated during backincr()
   my $xttplanpath = "$tmp/xttplan.txt";
   my $xttplanpathnew = "$tmp/xttplan.txt.new";

   checkCopy($xttplanpathnew);
   checkCopy($xttplanpath);

   if ( -e $xttplanpath )
   {
      # It sounds silly to do a copy and remove, but a lot of customers
      # get confused with the timestamp when move happens
      checkCopy($xttplanpathnew, $xttplanpath);
      Unlink($xttplanpathnew);
   }

   ## Checks that no tablespace went read only
   ## or datafiles offline
   &generate_batch_tsoutput(NEWPLAN);

   Mylog("New $tmp/xttplan.txt with FROM SCN's generated");
   copyImpfiles();
   return;
}

###
### xttplan.txt with new fromscn -- ENDS
###

###
### Convert Starts here - on destination
###
### This function fixes new datafiles
sub fixNewDatafiles
{
   my @fixArr;
   my @convArr;
   my @newDFArr;
   my $copy;
   my $method;

   LogMessage ("Performing new datafile addition");
   # Check if any failure occured and stop exection
   checkErrFile();

   my ($rmanTrace, $traceFile) = GetRMANTrace("single convert");
   my $rmanConv = "$tmpMisc/single_rmanconv.cmd";
   my $xttnew = "$tmpMisc/xttnewdatafiles_newdfadded".$tstamp.".txt";
   my $xttorg = "$tmp/xttnewdatafiles.txt";

   checkMove($xttorg);
   
   open FILE, "$tmp/fixnewdf.txt";
   @fixArr =<FILE>;
   close FILE;

   foreach my $x (@fixArr)
   {
      if ($copy == 1)
      {
         push (@newDFArr, $x)
      }
      if ($copy == 3)
      {
         push (@convArr, $x)
      }
      if ($x =~ m/STARTXTTNEW/)
      {
         $copy = 1;
      }
      elsif ($x =~ m/ENDTXTTNEW/)
      {
         $copy = 2;
         pop (@newDFArr);
      }
      if ($x =~ m/STARTCONV::(.*)/)
      {
         $copy = 3;
         $method = $1;
      }
      elsif ($x =~ m/ENDCONV/)
      {
         $copy = 4;
         pop (@convArr);
      }
   }

   open FILE, ">$rmanConv";
   print FILE @convArr;
   close FILE;

   open FILE, ">$xttorg";
   foreach my $x (@newDFArr)
   {
      chomp($x);
      if ($x =~ /^(.*):::SCN:::(.*)$/)
      {
         print FILE "$1\n";
      }
      else
      {
         print FILE "$x\n";
      }
   }
   close FILE;

   if ($method == GETFILE)
   {
      getFilesSource($rmanConv);
   }
   elsif ($method == BACKUP)
   {
      restoreNewDf($rmanConv);
   }
   else
   {
      my $output = RunRmanCmd($rman_dest_connstr, $rmanConv, "fixnewdf");
      if ($output =~ /ERROR MESSAGE/)
      {
         Die("$output $!");
      }
      LogMessage ("Datafiles Converted");
      system ("mv $rmanConv ".$rmanConv.$tstamp);
   }
}

sub readFileNormal
{
   my $inFile        = $_[0];
   my $noErr         = $_[1];
   my @filArray = ();

   if (!$noErr && (!-e $inFile))
   {
      Die ("Unable to open file $inFile");
   }

   open FILE, "$inFile";
   while (<FILE>)
   {
      my $x = $_;
      chomp($x);
      push (@filArray, $x."\n");
   }
   close FILE;

   return @filArray;
}

###############################################################################
# Function : sortEleHash
# Purpose  : Check if duplicate element exists in array
###############################################################################
sub sortEleHash
{
   #perl function 'stat' returns array of info on a file
   #10th element of the stat array is last modified date,
   #returned as number of seconds since 1/1/1970.
   my $x = trim($a);
   my $y = trim($b);
 
   if ($x =~ m/#(.*?):::/)
   {
      $x = $1;
   }
   elsif ($x =~ m/(.*?):::/)
   {
      $x = $1;
   }
   if ($y =~ m/#(.*?):::/)
   {
      $y = $1;
   }
   elsif ($y =~ m/(.*?):::/)
   {
      $y = $1;
   }

   return $x <=> $y;
}

sub fixComFile
{
   my @array = readFileNormal($compFile, 1);

   if (scalar @array)
   {
      open FILE, ">$compFile";
      @array = sort sortEleHash @array;
      foreach my $x (@array)
      {
         print FILE "$x";
      }
      close FILE;
   }
}

sub fixResFile
{
   my @array = readFileNormal($resFile, 1);

   if (scalar @array)
   {
      open FILE, ">$resFile";
      @array = sort sortEleHash @array;
      foreach my $x (@array)
      {
         print FILE "$x";
      }
      close FILE;
   }
}

###############################################################################
# Function : checkEleExists
# Purpose  : Check if duplicate element exists in array
###############################################################################
sub checkEleExists
{
   my @array = @{$_[0]};
   my $ele = $_[1];
   my $arrayCnt = scalar(@array);
   
   chomp ($ele);

   foreach my $x (@array)
   {
      chomp ($x);
      if ($x eq $ele)
      {
         return 1;
      }
   }

   return 0;
}

sub updateFailed
{
   my ($lineP, $dfNo, $fName, $outFull, $outputArrayP, $tbsStr) = @_;
   my @outputArray = @$outputArrayP;
   my @dfSucArray = ();
   my $fName = '';
   my $errorSeen = 0;
   my (@linePArray, @addEntArray) = ();
   my $convTime = time;
   my $addEntry;
   my @dfArray = ();
   
   open FIL_LCK, ">$dfLck";
   flock(FIL_LCK, LOCK_EX);

   open FILE, "$failedDf";
   @dfArray = <FILE>;
   close FILE;

   open FILE, ">$failedDf";

   for (my $i = $#dfArray; $i > -1; $i--)
   {
      if ($dfArray[$i] =~ m/.*:::(.*?),.*/)
      {
         if ($1 != $dfNo)
         {
            print FILE $dfArray[$i];
         }
      }
   }

   print FILE $lineP."\n";
   close FILE;

   close FIL_LCK;
}

sub updateRestoreDFCopy
{
   my ($lineP, $dfNo, $fName, $outFull, $outputArrayP, $tbsStr) = @_;
   my $result = "Success";
   my @outputArray = @$outputArrayP;
   my @dfSucArray = ();
   my $errorSeen = 0;
   my (@linePArray, @addEntArray) = ();
   my $convTime = time;
   my $addEntry;
   my $doConvert = 1;
   my $errorLog = '';
   my $copyName = $dfNo.":::".$fName;
   my $tbsComp = "$tmp/tsbkupmap_comp.txt";

   foreach my $output (@outputArray)
   {
      if ($output =~ /ERROR MESSAGE/)
      {
         Warn("$output $!");
         updateFailed(@_);
         exit (0);
      }
   }

   open FIL_LCK, ">$dfLck";
   flock(FIL_LCK, LOCK_EX);

   open FILE, "$failedDf";
   @outputArray = <FILE>;
   close FILE;

   for (my $i = $#outputArray; $i > -1; $i--)
   {
      #  Delete element here if it matches.
      if ($outputArray[$i] =~ m/.*:::(.*?),.*/)
      {
         if ($1 == $dfNo)
         {
            splice @outputArray, $i, 1;
         }
      }
   }
   # Test  

   open FILE, ">$failedDf";
   if ($#outputArray > 0)
   {
      foreach my $x (@outputArray)
      {
         $x = trim($x);
         print FILE $x."\n";
      }
   }
   close FILE;

   open FILEC, ">>$compFile";
   $lineP = trim($lineP);
   print FILEC "$lineP\n";
   close FILEC;

   fixComFile();

   if ($outFull)
   {
      @outputArray = readFileNormal($dfCopyFile, 1);

      for (my $i = $#outputArray; $i > -1; $i--)
      {
         #  Delete element here if it matches.
         if ($outputArray[$i] =~ m/(.*):::.*/)
         {
            if ($1 == $dfNo)
            {
               splice @outputArray, $i, 1;
            }
         }
      }

      open FILE, ">$dfCopyFile";
      foreach my $x (@outputArray)
      {
         $x = trim($x);
         print FILE $x."\n";
      }
      close FILE;
      open FILEX, ">>$dfCopyFile" or Die ("unable to open file $!");
      print FILEX $dfNo.":::".$outFull."\n";
      close FILEX;
   }

   if ($tbsStr)
   {
      open(MYFILE, ">>$tbsComp");
      $tbsStr = trim($tbsStr);
      print MYFILE "$tbsStr\n";
      close(MYFILE);
   }
   
   close FIL_LCK;
}

sub performConvert11G
{
   my ($lineP, $compArrayP) = @_;
   my @compArray = @$compArrayP;
   my $dfNo;
   my $rmanConvertCmd;
   my $inFull;
   my $outFull;
   my $platName = $context->{"platname"};
   my $fName = '';

   #0:::9,13,TBS_2_9.tf,0,1656520,6530515,0,209715200,BKP1,DBMIG
   debug "$lineP\n";
   if ($lineP =~ m/.*:::(.*?),.*,(.*)/)
   {
      $dfNo = $1;
      $fName = $2;
      if ($fName =~ m/(.*)\.dbf/)
      {
         $fName = $1;
      }
   }

   checkCompleted($lineP, \@compArray);
   LogMessage ("Performing convert for file $dfNo");

   $inFull = $props{'stageondest'}."/"."$fName".".tf";
   $outFull = $props{'storageondest'}."/"."$fName".".dbf";
   $rmanConvertCmd = "$tmpMisc/rman_convert_$fName.cmd";

   open FILE, ">$rmanConvertCmd";
   print FILE
   "convert from platform \'$platName\' datafile ".
   " \'$inFull\' format \'$outFull\' ;\n";
   close FILE;

   my @output = RunRmanCmd($rman_dest_connstr, $rmanConvertCmd, "convert", 1);

   updateRestoreDFCopy($lineP, $dfNo, $fName, $outFull, \@output, 0);
}

sub performRecover11G
{
   my ($lineP, $compArrayP) = @_;
   my @compArray = @$compArrayP;
   my $dfNo;
   my $rmanConvertCmd;
   my $inFull;
   my $outFull;
   my $platName = $context->{"platname"};
   my $fName = '';

   #0:::9,13,TBS_2_9.tf,0,1656520,6530515,0,209715200,BKP1,DBMIG
   if ($lineP =~ m/.*:::(.*?),.*?,(.*?),.*/)
   {
      $dfNo = $1;
      $fName = $2;
      if ($fName =~ m/(.*)\.tf/)
      {
         $fName = $1;
      }
   }

   checkCompleted($lineP, \@compArray);
   LogMessage ("Performing recover for file $dfNo");
   LogMessage ("Need to implement recover");
   $inFull = $props{'stageondest'}."/"."$fName".".tf";
   $outFull = $props{'storageondest'}."/"."$fName".".dbf";
   my @output = ();
   updateRestoreDFCopy($lineP, $dfNo, $fName, $outFull, \@output, 0);
}

sub checkCompleted
{
   my ($lineP, $dfCompArrayP) = @_;
   my @dfCompArray = @$dfCompArrayP;
   my $dfNo;

   #0:::9,13,TBS_2_9.tf,0,1656520,6530515,0,209715200,BKP1,DBMIG
   if ($lineP =~ m/.*:::(.*?),.*?,(.*?),.*/)
   {
      $dfNo = $1;
   }

   if (checkEleExists(\@dfCompArray, $lineP))
   {
      LogMessage("File $dfNo already completed");
      exit (0);
   }
}

sub gentsbkup
{
   my ($inArrayP) = @_;  
   my @inArray = @$inArrayP;
   my %tbsHash = ();
   my $tbsHashP = \%tbsHash;

   foreach my $x (@inArray)
   {
      $x = trim ($x);
      if ($x =~ m/#(.*):::(.*),.*?,(.*),.*?,.*?,.*?,.*?,.*?,(.*?),.*?/)
      {
         my $level = $1;
         my $fno = $2;
         my $bpname = $3;
         my $tbname = $4;
         push(@{$tbsHashP->{$bpname}->{"files"}}, $fno);
         $tbsHashP->{$bpname}->{"tbname"} = $tbname;
         $tbsHashP->{$bpname}->{"level"} = $level;
      }
   }

   open FILE, ">$tsbkupmapWhole";

   foreach my $x (sort keys %tbsHash)
   {
      my @localArray1 = @{$tbsHashP->{$x}->{"files"}};
      my @localArray2 = join(',', @localArray1);
      my $level = $tbsHashP->{$x}->{"level"};
      my $tbname = $tbsHashP->{$x}->{"tbname"};
      print FILE $level."::".$tbname."::".join(',', @localArray1).
                 ":::1="."$x\n";
      foreach my $y (@localArray2)
      {
         debug "$y\n";
      }
   }

   close FILE;
}

sub findDiffArray
{
   my ($firstArrayP, $secondArrayP) = @_;
   my @firstArray = @$firstArrayP;
   my @secondArray = @$secondArrayP;
   my @diffLevel0Array;
   my @diffLevelOthersArray;

   my %disabled = map {($_, 1)} @secondArray;
   my @diffArray = grep {!$disabled{$_}} @firstArray;

   foreach my $x (@diffArray)
   {
      $x = trim ($x);
      if ($x =~ m/#(.*):::.*/)
      {
         my $level = $1;
         if ($level == 0)
         {
            push(@diffLevel0Array, $x."\n");
         }
         else
         {
            push(@diffLevelOthersArray, $x."\n");
         }
      }
   }

   return (\@diffLevel0Array, \@diffLevelOthersArray);
}

sub writeTBS
{
   my @inArray = @_;

   open FILE, ">$tsbkupmap";
   foreach my $x (@inArray)
   {
      $x = trim($x);
      print FILE "$x\n";
   }
   close FILE;
}

sub performRes11G
{
   my @filArray = ();
   my @convertArray = ();
   my @compArray = ();
   my $diffLevel0P;
   my $diffLevelOthersP;
   my @diffLevel0Array;
   my @diffLevelOthersArray;
   my @currArray = ();

   # Check if any failure occured and stop exection
   checkErrFile();

   @filArray = readFileNormal($resFile, 1);
   @compArray = readFileNormal($compFile, 1);

   ($diffLevel0P, $diffLevelOthersP) = findDiffArray (\@filArray, \@compArray);
   @diffLevel0Array = @$diffLevel0P;
   @diffLevelOthersArray = @$diffLevelOthersP;

   foreach my $x (@diffLevel0Array)
   {
      $x = trim($x);
      ChecktoProceed($rollParallel);
      my $pid = fork();

      if ($pid == 0)
      {
         performConvert11G($x, \@compArray);
         exit (0);
      }
      else
      {
         UpdateForkArray ($pid, $rollParallel);
      }
   }

   while((my $pid = wait()) > 0)
   {
      #sleep (1);
   }

   gentsbkup(\@diffLevelOthersArray);
   @diffLevelOthersArray = readFileNormal($tsbkupmapWhole, 1);
   my $level = 0;

   foreach my $x (@diffLevelOthersArray)
   {
      $x = trim($x);
      if ($x =~ m/(.*?)::(.*)/)
      {
         my $currLevel = $1;
         my $tbs = $2;
         if ($level and $currLevel > $level)
         {
            writeTBS(@currArray);
            @currArray = ();
            push (@currArray, $tbs);
            rollforward();
            $level = $currLevel;
         }
         else
         {
            $level = $currLevel;
            push(@currArray, $tbs);
         }
      }
   }
   debug "YYY: @currArray\n";
   if (scalar @currArray > 0)
   {
      writeTBS(@currArray);
      @currArray = ();
      rollforward();
   }
   fixResFile();
}

sub genXTTDatafile
{
   my @filArray = readFileNormal($resFile, 1);
   my $storageondest = $props{'storageondest'};

   my @fileArray = ();
   my %dupHash = ();
   my $dupHashP = \%dupHash;

   open FILE, ">$xttnew";

   foreach my $x (@filArray)
   {
      $x = trim ($x);
      if ($x =~ m/.*:::(.*?),.*,(.*)/)
      {
         my $fno = $1;
         my $lineP = "$fno,$storageondest/$2";
         if (!defined $dupHashP->{$fno})
         {
            $dupHashP->{$fno} = 1;
            print FILE "$lineP\n";
         }
      }
   }
   close FILE;
}

sub performRes12C
{
   my @filArray = ();
   my @convertArray = ();
   my @compArray = ();
   my $diffLevel0P;
   my $diffLevelOthersP;
   my @diffLevel0Array;
   my @diffLevelOthersArray;
   my @currArray = ();
   my $level = 0;

   # Check if any failure occured and stop exection
   checkErrFile();

   @filArray = readFileNormal($resFile, 1);
   @compArray = readFileNormal($compFile, 1);

   ($diffLevel0P, $diffLevelOthersP) = findDiffArray (\@filArray, \@compArray);
   @diffLevel0Array = @$diffLevel0P;
   @diffLevelOthersArray = @$diffLevelOthersP;

   if (scalar @diffLevel0Array > 0)
   {
      debug "YYY: CAme here\n";
      genXTTDatafile();
      gentsbkup(\@diffLevel0Array);
      @diffLevel0Array = readFileNormal($tsbkupmapWhole, 1);

      foreach my $x (@diffLevel0Array)
      {
         $x = trim($x);
         if ($x =~ m/(.*?)::(.*)/)
         {
            my $tbs = $2;
            push(@currArray, $tbs);
         }
      }
      writeTBS(@currArray);
      @currArray = ();
      resrecBkp(RESTORE);
   }

   gentsbkup(\@diffLevelOthersArray);
   @diffLevelOthersArray = readFileNormal($tsbkupmapWhole, 1);

   foreach my $x (@diffLevelOthersArray)
   {
      $x = trim($x);
      if ($x =~ m/(.*?)::(.*)/)
      {
         my $currLevel = $1;
         my $tbs = $2;
         if ($level and $currLevel > $level)
         {
            writeTBS(@currArray);
            @currArray = ();
            push (@currArray, $tbs);
            resrecBkp(RECOVER);
            $level = $currLevel;
         }
         else
         {
            $level = $currLevel;
            push(@currArray, $tbs);
         }
      }
   }
   debug "YYYZ: @currArray\n";
   if (scalar @currArray > 0)
   {
      writeTBS(@currArray);
      @currArray = ();
      resrecBkp(RECOVER);
   }
   fixResFile();
}

###############################################################################
# Function : genConvertDFNames
# Purpose  : When script is used to transport tablespaces between same endian
#            this function will be called. Here we create xttnewdatafiles.txt
###############################################################################
sub genConvertDFNames
{
   my @convertArray = ();

   # Check if any failure occured and stop exection
   checkErrFile();

   open(RMANCONVERT, "$rmanpath") ||
       die 'Cant find rmanconvert.cmd, TMPDIR undefined';
   @convertArray = <RMANCONVERT>;
   close RMANCONVERT;

   open(RMANDSTDF, ">$rmandstdf") ||
      Die "Cant find $rmandstdf";

   foreach my $x (@convertArray)
   {
      chomp($x);
      $x = trim($x);
      if ($x =~ /'(.*)\.tf'/)
      {
         $x = $1.".tf";
         if ($x =~ /.*(.+)\/(\w+)[_](\d+)\.tf/)
         {
            print RMANDSTDF "::$2\n";
            print RMANDSTDF "$3,$x\n";
         }
      }
   }

   close RMANDSTDF;
   copyImpfiles();
   exit;
}

###############################################################################
# Function : genConvertDFNamesCrossEnd
# Purpose  : When script is used to transport tablespaces between diff endian
#            this function will be called. Here we create xttnewdatafiles.txt
###############################################################################
sub genConvertDFNamesCrossEnd
{
   my @lines = split /\n/, $_[0];
   my @convertArray = ();
   my $tsname = 0;
   my $dfno = 0;

   # Check if any failure occured and stop exection
   checkErrFile();

   if ($rmanLog)
   {
       open(RMANCONVERT, "$rmanpath") ||
          die 'Cant find rmanconvert.cmd, TMPDIR undefined';
      @convertArray = <RMANCONVERT>;
      close RMANCONVERT;

      if (-e $rmandstdf)
      {
         system ("mv $rmandstdf ".$rmandstdf.$tstamp);
      }

      open(RMANDSTDF, ">$rmandstdf") ||
         Die "Cant find $rmandstdf";

      foreach my $x (@convertArray)
      {
         chomp($x);
         $x = trim($x);
         if ($x =~ /'(.*)\.tf'/)
         {
            $x = $1.".tf";
            if ($x =~ /.*(.+)\/(\w+)[_](\d+)\.tf/)
            {
               if ($tsname ne $2)
               {   
                  print RMANDSTDF "::$2\n";
                  $tsname = $2;
               }
               $dfno = $3;
               if ($x =~ /(.*)\/(.*)\.tf/)
               {
                  $x = $props{'storageondest'}."/".$2.".dbf";
               }
               print RMANDSTDF "$dfno,$x\n";
            }
         }
      }
      close RMANDSTDF;
   }
   else
   {
      my $xttnewdata = "$tmp/xttnewdatafiles.txt";

      if ( -e $xttnewdata )
      {
         checkMove ($xttnewdata);
      }

      open(XTTNEW, ">$xttnewdata") || Die("Cant open xttnewdatafiles.txt");

      foreach my $line (@lines)
      {
         my $tsname;
         my $filno;

         $_ = $line;

         if (/converted datafile=(.+)\/(\w+)[_](\d+)\.dbf/)
         {
            print XTTNEW "$3,";
            $line =~ s/.*converted datafile=//;
            print XTTNEW "$line\n";
         }
         elsif(/^ts(\S+)/)
         {
            print XTTNEW $1 . "\n";
            $tsname = $1;
         }
      }
      close(XTTNEW);
      LogMessage ("Converted datafiles listed in: $xttnewdata");
   }
   copyImpfiles();
   exit;
}

###
### Convert Ends here - on destination
###

###
### Generate plugin/impdp command template as xttplugin.txt
### - Starts here, on destination
###
sub plugin
{
   my $option = $_[0];

   LogMessage ("Generating plugin");
   # Check if any failure occured and stop exection
   checkErrFile();

   my $xttplugin = "$tmp/xttplugin.txt";
   my $tts       = "transport_tablespaces=";
   my $tdf       = "transport_datafiles=";
   my $comma     = 0;
   my $xttnewdata = "$tmp/xttnewdatafiles.txt";
   my $command_str;
   my $dmpFile = $context->{"dmpfile"};

   checkMove($xttplugin);

   open(XTTPLUG, ">$xttplugin") || Die("Unable to open file $xttplugin");

   if ($option == LINK)
   {
      $command_str =
        "impdp directory=<DATA_PUMP_DIR> logfile=<tts_imp.log> \\" . "\n" .
        "network_link=<ttslink> transport_full_check=no \\" . "\n" ;
   }
   else
   {
      $command_str =
        "impdp directory=<DATA_PUMP_DIR> logfile=<tts_imp.log> \\" . "\n" .
        "dumpfile=$dmpFile \\" . "\n" ;
   }

   print XTTPLUG $command_str;

   if ($option == LINK)
   {
      print XTTPLUG $tts;

      open(XTTPLAN, $xttpath) || Die("Cant find xttplan.txt\n $!");

      while (<XTTPLAN>)
      {
         if ($comma == 1 && /::::/)
         {
            print XTTPLUG ",";
            $comma = 0;
         }
         if (/(\S+)::::(\S+)/)
         {
            print XTTPLUG $1;
            $comma = 1;
         }
      }
      close(XTTPLAN);

      print XTTPLUG " \\\n";
   }
   print XTTPLUG $tdf;
   $comma = 0;

   open(XTTNEWDATA, $xttnewdata) || Die("Cant find xttnewdatafiles.txt\n $!");

   while (<XTTNEWDATA>)
   {
      if ($comma == 1)
      {
         print XTTPLUG ",";
         $comma = 0;
      }
      if (! /^::\S+/)
      {
         chop;

         my ($dfno, $dfname) = split /,/, $_;

         print XTTPLUG  "'" . $dfname . "'";
         $comma = 1;
      }
   }

   print XTTPLUG "\n";

   close(XTTNEWDATA);
   close(XTTPLUG);

   LogMessage ("Done generating plugin file $xttplugin");
   copyImpfiles();
   exit;
}

###
### Generate plugin/impdp command - Ends here, on destination
###

###############################################################################
# Function : usage
# Purpose  : Message about this program and how to use it
###############################################################################
sub usage
{
   print STDERR << "EOF";

   This program prepares, backsup and rollsforward tablespaces
   for cross-platform transportable tablespaces.

    usage: $0
                  {[--backup|-b] || [--bkpincr|-B] || [--bkpexport/E]
                   [--resincrdmp|M]
                   [--fixnewdf|W]
                   [--convert/-c] || [--generate|-e] || [--incremental|-i] ||
                   [[--prepare|-p] || [--getfile|-G]] ||
                   [--restore|R] || [--recover|X]
                   [--rollforward|-r [--rolltbs|-T <TBS1[,TBS2]>] ||
                   [--determinescn|-s] ||
                   [--orasid/O] || [--orahome|-o]]
                   [--help|-h]}

       Additional options
       ------------------
               [--debug|d] [--clearerrorfile|-C] [--xttdir|Dir <tmpdir>]
               [-F/--propfile] [-I/--propdir]

     -b  : For 12c and above, generate transportable backups
     -B  : For 12c and above, generate level 1 transportable backups
     -c  : conversion of datafiles
     -M  : create the dump file from the generated backup
     -e  : generate impdp script: export over new link
     -i  : incremental backup
     -p  : prepare
     -G  : get datafiles from source database using get_file, should not
           be used together with -p
     -r  : roll forward datafiles
     -s  : new from_scn values into xttplan.txt
     -R  : For 12c restore the datafiles from the backups
     -X  : For 12c recover the datafiles from the backups
     -T  : roll forward specific tablespace(s)
     -h  : this (help) message (Default)
     -d  : provides more debug information, also rman is called with debug
           option so that tracing is better.
     -L  : delete the ERROR FILE and proceed with the execution
     -D  : Instead of defining environement variable, user can pass tmpdir
           through xttdir
     -O  : Use this option to pass ORACLE_SID to override the environment
           variable
     -o  : Use this option to pass ORACLE_HOME to override the environment
           variable
     -I  : Use this option to mention the location from where the script
           will pick the properties file etc
     -F  : Use this option to mention the location from where the script
           will pick the properties file.
     -W  : Will try to reconstruct files on the destination after new 
           datafiles have been added

    example: $0 -p
             $0 -i
             $0 -r
             $0 -s

EOF
   exit;
}

###############################################################################
# Function : strLPad
# Purpose  : Pads a string on the left end to a specified length with a 
#            specified character and returns the result.  Default pad char is 
#            0.
###############################################################################
sub strLPad 
{
   my($str, $len) = @_;
   my $chr = "0";
       
   return substr(($chr x $len) . $str, -1 * $len, $len);
}

###############################################################################
# Function : strRpad
# Purpose  : Pads a string on the right end to a specified length with a 
#            specified character and returns the result.  Default pad char is 
#            0.
###############################################################################
sub strRpad 
{
   my($str, $len) = @_;
   my $chr = "0";
       
   return substr($str . ($chr x $len), 0, $len);
}

###############################################################################
# Function : GetTimeStamp
# Purpose  : Get the time stamp
# Inputs   : None
# Outputs  : Timestamp
# NOTES    : None
###############################################################################
sub GetTimeStamp
{
   my @months = qw( Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec );
   my @days = qw(Sun Mon Tue Wed Thu Fri Sat Sun);
   my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime();
   my $timeStamp = $months[$mon].$mday."_".$days[$wday];
   $timeStamp = $timeStamp."_".strLPad($hour,2)."_".strLPad($min,2)."_".
                strLPad($sec,2)."_".int(rand(1000));

   return ($timeStamp);
}

sub clearResFile
{
   my %seen;

   grep { not $seen{$_}++ } @_;
}

sub readFileNormal
{
   my $inFile        = $_[0];
   my $noErr         = $_[1];
   my @filArray = ();

   if (!$noErr && (!-e $inFile))
   {
      Die ("Unable to open file $inFile");
   }

   open FILE, "$inFile";
   while (<FILE>)
   {
      my $x = $_;
      chomp($x);
      push (@filArray, $x."\n");
   }
   close FILE;

   return @filArray;
}

sub genResFileNew
{
   my @xttArray = ();
   my @xttArrayNew = ();
   my $tbsName = '';
   my $scn = '';
   my $level = 0;
   my $fno = 0;
   my $fName = '';
   my @xttDataArray = ();
   my %resHash = ();
   my $resHashP = \%resHash;
   my @tbsArray = ();
   my $fileStr;
   my $bkpName;
   my @fileArray = ();

   $level = 0;
   @xttArray = readFileNormal($xttplan, 1);

   foreach my $x (@xttArray)
   {
      $x = trim($x);
      if ($x =~ m/(.*)::::(.*)/)
      {
         $scn = $2;
         $tbsName = $1;
      }
      else
      {
         $resHashP->{"$x"}->{"scn"} = $scn;
         $resHashP->{"$x"}->{"tbsname"} = $tbsName;
      }
   }

   @tbsArray = readFileNormal($tbsMap, 1);
   foreach my $x (@tbsArray)
   {
      $x = trim ($x);
      debug "XXX: $x\n";
      if ($x =~ m/.*?::(.*?):::.*=(.*)/)
      {
         $fileStr = $1;
         $bkpName = $2;
         @fileArray = split /,/, $fileStr;
         foreach my $y (@fileArray)
         {
            $resHashP->{"$y"}->{"bpname"} = $bkpName;
         }
      }
   }

   @xttDataArray = readFileNormal($xttnew, 1);

   open FILE, ">$resFile";
   foreach my $x (@xttDataArray)
   {
      if ($x =~ m/(.*),.*\/(.*)/)
      {
         $fno = $1;
         $fName = $2;
         if ($fName =~ m/(.*)\..*/)
         {
            $fName = $1.".dbf";
         }
         $scn = $resHashP->{"$fno"}->{"scn"};
         $tbsName = $resHashP->{"$fno"}->{"tbsname"};
         if (!defined($resHashP->{"$fno"}->{"bpname"}))
         {
            $bkpName = $fName;
         }
         else
         {
            $bkpName = $resHashP->{"$fno"}->{"bpname"};
         }
         print FILE "#"."$level".":::"."$fno,$platId,$bkpName,0,$scn,0,0,0,$tbsName,$fName\n";
      }
   }
   close FILE;
}

sub copyResFile
{
   if ($metaTransfer)
   {
      my @trnsfrFiles = ();
      push (@trnsfrFiles, "$resFile");
      transferFiles (@trnsfrFiles);
   }
}

sub genResFile
{
   my ($fileArrayP) = @_;
   my @fileArray;
   if (defined $fileArrayP)
   {
      @fileArray = @$fileArrayP;
   }
   if (!-e $resFile)
   {
      genResFileNew();
      return;
   }
   my @xttArray = ();
   my @xttArrayNew = ();
   my $tbsName = '';
   my $scn = '';
   my $level = 0;
   my $fno = 0;
   my $fName = '';
   my @xttDataArray = ();
   my %resHash = ();
   my $resHashP = \%resHash;
   my @resArray = ();
   my $highscn;
   my $lowscn;
   my @tbsBkupArr = ();
   my %tbsHash;
   my $tbsHashP = \%tbsHash;

   $level = 0;
   @xttArray = readFileNormal($xttplan, 1);
   @xttArrayNew = readFileNormal($xttplanNew, 1);
   @resArray = readFileNormal($resFile, 1);
   @tbsBkupArr = readFileNormal($tbsMap, 1);

   foreach my $x (@resArray)
   {
      $x = trim($x);
      if ($x =~ m/#(.*?):::(.*?),.*?,(.*?),.*?,(.*?),.*?,.*?,.*?,(.*?),(.*)/)
      {
         $level = $1;
         $fno = $2;
         my $bpname = $3;
         $highscn = $4;
         $tbsName = $5;
         $fName = $6;

         if (!defined($resHashP->{"$fno"}->{"fname"}))
         {
            $resHashP->{"$fno"}->{"fname"} = $fName;
         }
         if (!defined($resHashP->{"$fno"}->{"tbsname"}))
         {
            $resHashP->{"$fno"}->{"tbsname"} = $fName;
         }
         $resHashP->{"$fno"}->{"level"} = $level;
         $resHashP->{"$fno"}->{"lowscn"} = $highscn;
         $resHashP->{"$fno"}->{"bpname"} = $bpname;
      }
   }

   #0:::9,13,TBS_2_9.tf,0,1656520,6530515,0,209715200,TBS_2,DBMIG
   #0:::6,13,VB$_1957073580_6527411I,0,1656520,6530515,0,209715200,BKP1,DBMIG
   foreach my $x (@xttArrayNew)
   {
      $x = trim($x);
      if ($x =~ m/(.*)::::(.*)/)
      {
         $scn = $2;
         $tbsName = $1;
         $tbsHashP->{"$tbsName"}->{"scn"} = $scn;
      }
      else
      {
         $resHashP->{"$x"}->{"highscn"} = $scn;
      }
   }

   @xttDataArray = readFileNormal($xttnew, 1);

   foreach my $x (@xttDataArray)
   {
      if ($x =~ m/::(.*)/)
      {
         $tbsName = $1;
      }
      elsif ($x =~ m/(.*),.*\/(.*)/)
      {
         $fno = $1;
         $fName = $2;
         if ($fName =~ m/(.*)\..*/)
         {
            $fName = $1.".dbf";
         }
         if (!defined($resHashP->{"$fno"}->{"fname"}))
         {
            $resHashP->{"$fno"}->{"fname"} = $fName;
         }
         if (!defined($resHashP->{"$fno"}->{"lowscn"}))
         {
            $resHashP->{"$fno"}->{"lowscn"} = 0;
         }
         if (!defined($resHashP->{"$fno"}->{"level"}))
         {
            $resHashP->{"$fno"}->{"level"} = -1;
         }
         if (!defined($resHashP->{"$fno"}->{"tbsname"}))
         {
            $resHashP->{"$fno"}->{"tbsname"} = $tbsName;
         }
      }
   }

   @tbsBkupArr = readFileNormal($tbsMap, 1);

   foreach my $x (@tbsBkupArr)
   {
      $x = trim($x);
      if ($x =~ m/.*?::(.*):::.*?=(.*)/)
      {
         my $fileStr = $1;
         my $bpname = $2;
         my @fileArray = split /,/, $fileStr;
         foreach my $y (@fileArray)
         {
            debug4 "tbsBkupArr: $y, $bpname";
            $resHashP->{"$y"}->{"bpname"} = $bpname;
            $resHashP->{"$y"}->{"modified"} = 1;
         }
      }
   }

   foreach my $x (keys %resHash)
   {
      $fno = $x;
      debug4("ResHash: $x");
      if (scalar @fileArray > 0 &&
          checkEleExists(\@fileArray, $fno))
      {
         next;
      }
      if (defined($resHashP->{"$fno"}->{"fname"}) &&
          ($resHashP->{"$fno"}->{"level"} < 0 ||
           $resHashP->{"$fno"}->{"level"} >= 0))
      {
         $level = $resHashP->{"$fno"}->{"level"} + 1;
         $fName = $resHashP->{"$fno"}->{"fname"};
         $tbsName = $resHashP->{"$fno"}->{"tbsname"};
         if (!defined $resHashP->{"$fno"}->{"highscn"})
         {
            $highscn = $tbsHashP->{"$tbsName"}->{"scn"}
         }
         else
         {
            $highscn = $resHashP->{"$fno"}->{"highscn"};
         }
         $lowscn = $resHashP->{"$fno"}->{"lowscn"};
         my $bkpName = $resHashP->{"$fno"}->{"bpname"};
         if ($resHashP->{"$fno"}->{"modified"})
         {
            push (@resArray, "#"."$level".":::"."$fno,$platId,$bkpName,$lowscn,$highscn,0,0,0,$tbsName,$fName\n");
         }
         else
         {
            debug3("Bug29862901: Caught for file#: $fno");
         }
      }
   }

   my @fileArray = ();
   my %dupHash = ();
   my $dupHashP = \%dupHash;

   open FILE, ">$resFile";

   foreach my $x (@resArray)
   {
      $x = trim ($x);
      if (!exists $dupHashP->{$x})
      {
         $dupHashP->{$x} = 1;
         print FILE "$x\n";
      }
   }
   close FILE;
}

sub genResFileAdded
{
   my ($filHashP) = @_;;
   my @fileArray = readFileNormal($newfileAdded, 1);
   my @resFileArray = readFileNormal($resFile);
   my @oldfileArray = ();
   my @trnsfrFiles = ();

   foreach my $x (@resFileArray)
   {
      $x = trim ($x);
      if ($x =~ m/.*:::(.*?),.*/)
      {
         push (@oldfileArray, $1);
      }
   }

   open FILE, ">>$resFile";
   foreach my $x (@fileArray)
   {
      $x = trim($x);
      $x = fixSlashName($x);
      if ($x =~ m/(.*)=(.*?),(.*?),.*\/(.*)\..*/)
      {
         my $fno = $1;
         my $scn = $2;
         my $tbsName = $3;
         my $origFname = $4;
         my $fName = $4.".dbf";
         if (checkEleExists(\@oldfileArray, $fno))
         {
            next;
         }
         debug "genResFileAdded:$fno\n";
         if (defined($filHashP->{"$fno"}))
         {
            my $bkpName = $filHashP->{"$fno"}->{"bkpname"};
            debug "#0:::"."$fno,$platId,$bkpName,0,$scn,0,0,0,$tbsName,$fName\n";
            print FILE "#0:::"."$fno,$platId,$bkpName,0,$scn,0,0,0,$tbsName,$fName\n";
            $fName = fixSlashName($fName);
            if ($props{'usermantransport'})
            {
               $origFname = $bkpName;
            }
            else
            {
               $origFname = $origFname.".tf";
            }
            print "Adding file to transfer:".$origFname."\n";
            push (@trnsfrFiles, $props{'dfcopydir'}."/$origFname");
         }
      }
   }
   close FILE;
   if ($metaTransfer)
   {
      $context->{"desttmp"} = $props{'stageondest'};
      transferFiles (@trnsfrFiles);
      $context -> {"desttmp"} = $props{'desttmpdir'};
   }
}

## Call main function
Main();
