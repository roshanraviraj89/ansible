connect / as sysdba;

startup force nomount;

exit;
